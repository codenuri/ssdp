// Decorator - 65 page
#include <iostream>

class SpaceShip // ���� ���༱
{
public:
	void fire()	{ std::cout << "Fire Missile" << std::endl; }
};

int main()
{
	SpaceShip ss;
	ss.fire();
}