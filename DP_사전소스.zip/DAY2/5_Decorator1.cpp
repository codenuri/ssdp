﻿// Decorator - 65 page
#include <iostream>

class SpaceShip // 우주 비행선
{
public:
	void Fire()	{ std::cout << "Fire Missile" << std::endl; }
};

int main()
{
	SpaceShip ss;
	ss.Fire();
}
