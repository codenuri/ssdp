#include <iostream>
#include <string>
#include <map>
#include <functional>
#include <vector>
using namespace std::placeholders;


class NotificationCenter
{
public:
};

void foo(void* p)        { std::cout << "foo : " << (int)p << std::endl; }
void goo(void* p, int a) { std::cout << "goo : " << (int)p << std::endl; }


int main()
{
	NotificationCenter nc;

	nc.add_observer("LOWBATTERY", &foo);
	nc.add_observer("LOWBATTERY", &goo);

	// ���͸� ����ʿ��� ���͸��� ����������
	nc.post_notification_with_name("LOWBATTERY", (void*)30);
}




