﻿#include <iostream>

// chain of responsibility - 166

struct Handler
{
	Handler* next = nullptr;

	Handler* set_next(Handler* n) 
	{ 
		next = n; 
		return next; 
	}


	void handle(int problem)
	{
		if (resolve(problem) == true)
			return;

		if (next != 0)
			next->handle(problem);
	}

	virtual bool resolve(int problem) = 0;
};

int main()
{
}
