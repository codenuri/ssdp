﻿#include <iostream>

// chain of responsibility - 166

struct Handler
{
	Handler* next = nullptr;

	Handler* set_next(Handler* n) 
	{ 
		next = n; 
		return next; 
	}


	void handle(int problem)
	{
		if (resolve(problem) == true)
			return;

		if (next != 0)
			next->handle(problem);
	}

	virtual bool resolve(int problem) = 0;
};
//------------------------------------
class Team1 : public Handler
{
public:
	bool resolve(int problem) override
	{
		std::cout << "start Team1\n";

		if (problem == 7)
		{
			std::cout << "Team1 : Resolve the Problem\n";
			return true;
		}
		return false;
	}
};

int main()
{
}
