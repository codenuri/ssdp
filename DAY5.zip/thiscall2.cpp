﻿#include <functional> 

class Dialog
{
public:
	void Close1(int a) {}
	static void Close2(int a) {}
};
void foo(int a) {} 

int main()
{
	void(*f1)(int) = &foo;				// ok			
	void(*f2)(int) = &Dialog::Close1;	// ??
}






