#include <iostream>
#include <vector>
#include <stack>
#include "Helper.h"

class Shape
{
public:
	virtual void draw() = 0;
	virtual ~Shape() {}
};

class Rect : public Shape
{
public:
	void draw() override { std::cout << "draw Rect" << std::endl; }
};
class Circle : public Shape
{
public:
	void draw() override { std::cout << "draw Circle" << std::endl; }
};

// Command ���� : ������ ĸ��ȭ�ؼ� ������ ����/������ �����ϰ� �Ѵ�.
struct ICommand
{
	virtual void Execute() = 0;
	virtual bool CanUndo() { return false; }
	virtual void Undo() {}
	virtual ~ICommand() {}
};

// �簢���� �߰��ϴ� ����
class AddRectCommand : public ICommand
{
	std::vector<Shape*>& v; // �ٽ� : ����!!
public:
	AddRectCommand(std::vector<Shape*>& v) : v(v) {}

	void Execute() override { v.push_back(new Rect); }
	bool CanUndo() override { return true; }
	void Undo() override 
	{
		Shape* p = v.back();
		v.pop_back();
		delete p;
	}
};

class AddCircleCommand : public ICommand
{
	std::vector<Shape*>& v; 
public:
	AddCircleCommand(std::vector<Shape*>& v) : v(v) {}

	void Execute() override { v.push_back(new Circle); }
	bool CanUndo() override { return true; }
	void Undo() override
	{
		Shape* p = v.back();
		v.pop_back();
		delete p;
	}
};


class DrawCommand : public ICommand
{
	std::vector<Shape*>& v;
public:
	DrawCommand(std::vector<Shape*>& v) : v(v) {}

	void Execute() override { for (auto p : v) p->draw(); }
	bool CanUndo() override { return true; }
	void Undo() override    { system("cls"); }
};


int main()
{
	std::vector<Shape*> v;

	ICommand* pCommand = nullptr;

	std::stack<ICommand*> cmd_stack;

	while (1)
	{
		int cmd;
		std::cin >> cmd;

		if (cmd == 1)
		{
			pCommand = new AddRectCommand(v);
			pCommand->Execute();		
			cmd_stack.push(pCommand);
		}
		else if (cmd == 2)
		{
			pCommand = new AddCircleCommand(v);
			pCommand->Execute();
			cmd_stack.push(pCommand);
		}
		else if (cmd == 9)
		{
			pCommand = new DrawCommand(v);
			pCommand->Execute();
			cmd_stack.push(pCommand);
		}
		else if (cmd == 0)
		{
			if ( !cmd_stack.empty() )
			{
				pCommand = cmd_stack.top();
				cmd_stack.pop();

				if (pCommand->CanUndo())
					pCommand->Undo();

				delete pCommand; // ������ ���� redo_stack.push(pCommand)
								// �ϸ� redo �� �����մϴ�.
			}
		}
	}
}




