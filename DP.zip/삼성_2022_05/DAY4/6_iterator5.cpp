#include <iostream>

template<typename T> struct Node
{
	T     data;
	Node* next;

	Node(const T& d, Node* n) : data(d), next(n) {}
};

//----------------------------------------
template<typename T> class slist_iterator
{
	Node<T>* current;
public:
	slist_iterator(Node<T>* p = nullptr) : current(p) {}

	inline T& operator*()
	{
		return current->data;
	}
	inline slist_iterator<T>& operator++()
	{
		current = current->next;
		return *this;
	}
	// ==, != ������ �����ǵ� �ʼ� �Դϴ�.
	inline bool operator==(const slist_iterator& it) const
	{
		return current == it.current;
	}

	inline bool operator!=(const slist_iterator& it) const
	{
		return current != it.current;
	}

};








template<typename T> struct slist
{
	Node<T>* head = nullptr;
public:
	void push_front(const T& a) { head = new Node<T>(a, head); }

	// �����̳� �����ڴ� �ڽ��� �ݺ��� �̸��� ��ӵ� ����(iterator)��
	// �ܺο� �˷��� �Ѵ�.
	using iterator = slist_iterator<T>;

	iterator begin() { return iterator(head);	}
	iterator end()   { return iterator(nullptr); }
};

int main()
{
	slist<int> s;
	s.push_front(10);
	s.push_front(20);
	s.push_front(30);
	s.push_front(40);

	slist<int>::iterator p = s.begin();
	
	while (p != s.end())
	{
		std::cout << *p << std::endl;
		++p;
	}
}






