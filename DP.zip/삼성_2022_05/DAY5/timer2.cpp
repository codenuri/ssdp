#define USING_GUI
#include <iostream>
#include <string>
#include "cppmaster.h"
#include <map>

// Ÿ�̸� ������ ����ϴ� Clock �� ����� ���ô�.
class Clock
{
	std::string name;
	static std::map<int, Clock*> this_map;
public:
	Clock(const std::string& name) : name(name) {}

	void Start(int ms)
	{
		int n1 = ec_set_timer(ms, timerHandler);

		this_map[n1] = this;
	}
	static void timerHandler(int id)
	{
		Clock* pThis = this_map[id];

//		std::cout << name << std::endl; // this->name
		std::cout << pThis->name << std::endl; 
	}
};
std::map<int, Clock*> Clock::this_map;

int main()
{
	Clock c1("AAA");
	Clock c2("\tBBB");

	c1.Start(500); // 500 ms ���� �ڽ��� �̸� ���
	c2.Start(1000); 

	ec_process_message();
}