#define USING_GUI
#include "cppmaster.h"
#include <map>
#include <vector>

class CWnd
{
	int handle;

	static std::map<int, CWnd*> this_map;

	std::vector<CWnd*> child_window_vector;
	CWnd* parent = nullptr;
public:

	void AddChlid(CWnd* pchild)
	{
		child_window_vector.push_back(pchild);
		pchild->parent = this;

		ec_add_child(this->handle, pchild->handle);
	}


	void Create(const char* title)
	{
		handle = ec_make_window(&msg_proc, title);

		this_map[handle] = this;  
	}

	static int msg_proc(int hwnd, int msg, int a, int b)
	{
		CWnd* pThis = this_map[hwnd];


		switch (msg)
		{
		case WM_LBUTTONDOWN: pThis->LButtonDown(); break; // this->LButtonDown()
		case WM_KEYDOWN:     pThis->KeyDown();     break;
		}
		return 0;
	}

	virtual void LButtonDown() {}
	virtual void KeyDown() {}
};
std::map<int, CWnd*> CWnd::this_map;


class MyWindow : public CWnd
{
public:
	void LButtonDown() override { std::cout << "MyWindow LBUTTON" << std::endl; }
};

class ImageView : public CWnd
{
public:
	void LButtonDown() override { std::cout << "ImageView LBUTTON" << std::endl; }
};

int main()
{
	MyWindow w;
	w.Create("Sample");

	ImageView iv;
	iv.Create("ImageView");

	w.AddChlid(&iv);

	ec_process_message();
}
