#include <iostream>
#include <string>
#include <vector>
#include <conio.h> 
#include <memory> 
#include <functional>
using namespace std::placeholders;


class BadOperationException {};

class BaseMenu
{
	std::string title;
public:
	BaseMenu(const std::string& title) : title(title) {}

	virtual ~BaseMenu() {}

	std::string get_title() const { return title; }

	virtual void command() = 0;

	virtual void add_menu(std::shared_ptr<BaseMenu> p) { throw BadOperationException(); }
	virtual std::shared_ptr<BaseMenu> get_submenu(int idx) { throw BadOperationException(); }
};




class PopupMenu : public BaseMenu
{
	std::vector< std::shared_ptr<BaseMenu> > v;
public:
	PopupMenu(const std::string& title) : BaseMenu(title) {}


	void add_menu(std::shared_ptr<BaseMenu> p) override { v.push_back(p); }

	std::shared_ptr<BaseMenu> get_submenu(int idx) override { return v[idx]; }


	void command() override
	{
		while (1)
		{
			system("cls");

			int sz = v.size();

			for (int i = 0; i < sz; i++)
			{
				std::cout << i + 1 << ". " << v[i]->get_title() << std::endl;
			}

			std::cout << sz + 1 << ". ����" << std::endl;

			int cmd;
			std::cout << "�޴��� �����ϼ��� >> ";
			std::cin >> cmd;

			if (cmd < 1 || cmd > sz + 1)
				continue;

			if (cmd == sz + 1)
				break;

			v[cmd - 1]->command();
		}

	}

};

//��� 4. std::function ���

class MenuItem : public BaseMenu
{
	int id;
	using HANDLER = std::function<void()>; 
				// typedef std::function<void()> HANDLER; �� ����

	std::vector< HANDLER > v;

public:
	MenuItem(const std::string& title, int id, HANDLER h = nullptr) 
		: BaseMenu(title), id(id) 
	{
		if (h != nullptr)
			v.push_back(h);
	}

	void add_handler(HANDLER h) { v.push_back(h); }

	void command() override
	{
		for (auto f : v)
			f();
	}
};
//--------------------
void f0()      { printf("f0 \n"); }
void f1(int a) { printf("f1 %d\n", a); }
void f2(int a, int b) { printf("f2 %d, %d\n", a, b); }

class Camera
{
public:
	void take(int a, int b) { std::cout << "Camera take" << std::endl; }
};

int main()
{
	std::shared_ptr<PopupMenu> root = std::make_shared<PopupMenu>("ROOT");

	root->add_menu(std::make_shared<MenuItem>("HD", 11, &f0));
	root->add_menu(std::make_shared<MenuItem>("FHD",12, std::bind(&f1, 12)) );
	root->add_menu(std::make_shared<MenuItem>("UHD",13, std::bind(&f1, 13)));

	Camera cam;
	root->add_menu(std::make_shared<MenuItem>("SD", 14, 
						std::bind(&Camera::take, &cam, 1, 2)));// cam.take(1,2)

	root->add_menu(std::make_shared<MenuItem>("8K", 15, 
		[]() { std::cout << "8K" << std::endl; _getch(); }));
	
	std::shared_ptr<MenuItem> m = std::make_shared<MenuItem>("16k", 20);
	root->add_menu(m);

	m->add_handler(std::bind(&f2, 0, 0)); // ���ý� f2(0,0) ȣ��

	root->command();
}

// 3:40 ~ ���� �̾����ϴ�.



