#include <iostream>
#include <string>
#include <vector>
#include <conio.h> 
#include <memory> // C++ ǥ�� ����Ʈ ������.. 



class BadOperationException {};

class BaseMenu
{
	std::string title;
public:
	BaseMenu(const std::string& title) : title(title) {}

	virtual ~BaseMenu() {} // ��� Ŭ������ �Ҹ��ڴ� �����Լ� �̾�� �Ѵ�.

	std::string get_title() const { return title; }

	virtual void command() = 0;

	virtual void add_menu(std::shared_ptr<BaseMenu> p) { throw BadOperationException(); }
	virtual std::shared_ptr<BaseMenu> get_submenu(int idx) { throw BadOperationException(); }
};


class MenuItem : public BaseMenu
{
	int id;
public:
	MenuItem(const std::string& title, int id) : BaseMenu(title), id(id) {}

	void command() override
	{
		std::cout << get_title() << " �޴��� ���õ�" << std::endl;
		_getch();
	}
};

class PopupMenu : public BaseMenu
{
	std::vector< std::shared_ptr<BaseMenu> > v;
public:
	PopupMenu(const std::string& title) : BaseMenu(title) {}


	void add_menu(std::shared_ptr<BaseMenu> p) override { v.push_back(p); }

	std::shared_ptr<BaseMenu> get_submenu(int idx) override { return v[idx]; }


	void command() override
	{
		while (1)
		{
			system("cls");

			int sz = v.size();

			for (int i = 0; i < sz; i++)
			{
				std::cout << i + 1 << ". " << v[i]->get_title() << std::endl;
			}

			std::cout << sz + 1 << ". ����" << std::endl;

			int cmd;
			std::cout << "�޴��� �����ϼ��� >> ";
			std::cin >> cmd;

			if (cmd < 1 || cmd > sz + 1)
				continue;

			if (cmd == sz + 1)
				break;

			v[cmd - 1]->command();
		}

	}

};

int main()
{
	std::shared_ptr<PopupMenu> root = std::make_shared<PopupMenu>("ROOT");
	std::shared_ptr<PopupMenu> pm1 = std::make_shared<PopupMenu>("�ػ� ����");
	std::shared_ptr<PopupMenu> pm2 = std::make_shared<PopupMenu>("���� ����");
										// new PopupMenu("���� ����") �� �ǹ�
	root->add_menu(pm1);
	root->add_menu(pm2);

	pm1->add_menu(std::make_shared<MenuItem>("HD", 11));
	pm1->add_menu(std::make_shared<MenuItem>("FHD", 12));
	pm1->add_menu(std::make_shared<MenuItem>("UHD", 13));

	pm2->add_menu(std::make_shared<MenuItem>("RED", 21));
	pm2->add_menu(std::make_shared<MenuItem>("GREEN", 22));
	pm2->add_menu(std::make_shared<MenuItem>("BLUE", 23));

	root->command();

}




