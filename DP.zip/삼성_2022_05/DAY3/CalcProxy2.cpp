// CalcProxy2.cpp
#define USING_GUI
#include <atomic>
#include "cppmaster.h"
#include "ICalc.h"

class Calc : public ICalc
{
	int server;
	std::atomic<int> refCount = 0;
public:
	void AddRef()  { ++refCount; }
	void Release() { if (--refCount == 0) delete this; }


	~Calc() { std::cout << "~Calc" << std::endl; }

	Calc() { server = ec_find_server("Calc"); }

	int Add(int a, int b) override { return ec_send_server(server, 1, a, b); }
	int Sub(int a, int b) override { return ec_send_server(server, 2, a, b); }
};








extern "C" __declspec(dllexport)  
ICalc * CreateProxy()
{
	return new Calc;
}

// cl CalcProxy2.cpp /LD /link user32.lib gdi32.lib kernel32.lib

// �׸��� "CalcProxy2.dll" => "CalcProxy.dll" �� �̸� �����ϼ���..

