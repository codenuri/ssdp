#include <iostream>
#include <mutex>   // C++11 ���� mutex ����


class Cursor
{
private:
	Cursor() {}
	Cursor(const Cursor& c) = delete;
	Cursor& operator=(const Cursor& c) = delete;


	static std::mutex mtx;
	static Cursor* sInstance;
public:
	static Cursor& getInstance()
	{
		mtx.lock();

		if (sInstance == nullptr)
		{
			sInstance = new Cursor;
		}

		mtx.unlock();
		return *sInstance;
	}
};
Cursor* Cursor::sInstance = nullptr;
std::mutex Cursor::mtx;





int main()
{
	Cursor& c1 = Cursor::getInstance();
	Cursor& c2 = Cursor::getInstance();
}








