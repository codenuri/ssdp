#define USING_GUI
#include "cppmaster.h"
#include "ICalc.h"
#include "AutoPtr.h"

int main()
{
	void* addr = ec_load_module("CalcProxy.dll");
	typedef ICalc*(*F)();
	F f = (F)ec_get_function_address(addr, "CreateProxy");

	//---------------------------
	AutoPtr<ICalc> pCalc = f(); 
	AutoPtr<ICalc> pCalc2 = pCalc;

	std::cout << pCalc->Add(10, 20) << std::endl;
	std::cout << pCalc->Sub(10, 20) << std::endl;
}



// AutoPtr.h �� �����.. AutoPtr �ҽ��� ������ ��������.





