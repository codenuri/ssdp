// AutoPtr.h
#pragma once

template<typename T> class AutoPtr
{
	T* obj;
public:
	AutoPtr(T* p = 0) : obj(p) { if (obj) obj->AddRef(); }
	AutoPtr(const AutoPtr& ap) : obj(ap.obj) { if (obj) obj->AddRef(); }
	~AutoPtr() { if (obj) obj->Release(); }

	T* operator->() { return obj; }
	T& operator*() { return *obj; }
};