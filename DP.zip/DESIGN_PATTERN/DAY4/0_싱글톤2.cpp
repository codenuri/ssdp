// 7_�̱���1 - 123 page
#include <iostream>
using namespace std;

#include "helper.h"

// "helper.h" �� ���� �س�������..
// �̱����� ����� ��ũ��
/*
#define MAKE_SINGLETON(classname)			\
private:									\
	classname() {}							\
public:										\
	static classname& getInstance()			\
	{										\
	static classname instance;				\
		return instance;					\
	}										\
public:										\
	classname(classname&) = delete;			\
	void operator=(classname&) = delete;	
*/

class Cursor
{
	MAKE_SINGLETON(Cursor)
};


int main()
{
	Cursor& c1 = Cursor::getInstance();
	Cursor& c2 = Cursor::getInstance();

	cout << &c1 << endl;
	cout << &c2 << endl;
	
}








