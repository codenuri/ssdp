// 4_���丮�޼ҵ�
// 3_�߻����丮 - 147
#include <iostream>
using namespace std;

// ��� ������ ��Ʈ���� ������ ��� Ŭ���� �ʿ�
struct IButton
{
	virtual void Draw() = 0;
	virtual ~IButton() {}
};
struct IEdit
{
	virtual void Draw() = 0;
	virtual ~IEdit() {}
};


struct WinButton : public IButton
{
	void Draw() { cout << "Draw WinButton" << endl; }
};
struct WinEdit : public IEdit
{
	void Draw() { cout << "Draw WinEdit" << endl; }
};

struct OSXButton : public IButton
{
	void Draw() { cout << "Draw OSXButton" << endl; }
};
struct OSXEdit : public IEdit
{
	void Draw() { cout << "Draw OSXButton" << endl; }
};
//--------------------------------------
// Style �ɼǰ� ������� �׻� Windows ����� Dialog

class WinDialog
{
public:
	void init()
	{
		WinButton* btn  = new WinButton;
		WinEdit*   edit = new WinEdit;

		// btn->Move(); edit->Move();

		btn->Draw();
		edit->Draw();
	}
};
class OSXDialog
{
public:
	void init()
	{
		OSXButton* btn = new OSXButton;
		OSXEdit*   edit = new OSXEdit;

		// btn->Move(); edit->Move();

		btn->Draw();
		edit->Draw();
	}
};




int main(int argc, char** argv)
{

}








