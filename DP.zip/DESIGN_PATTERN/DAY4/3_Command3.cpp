#include <iostream>
#include <vector>
using namespace std;


class Shape
{
public:
	virtual void Draw() = 0;
	virtual ~Shape() {}
};


class Rect : public Shape
{
public:
	void Draw() override { cout << "Draw Rect" << endl; }
};
class Circle : public Shape
{
public:
	void Draw() override { cout << "Draw Circle" << endl; }
};

//------------------------------------

struct ICommand
{
	virtual void Execute() = 0;
	virtual bool CanUndo() { return false; }
	virtual void Undo() {}
	virtual ~ICommand() {}
};


class AddCommand : public ICommand
{
	std::vector<Shape*>& v;
public:
	AddCommand(std::vector<Shape*>& v) : v(v) {}

	void Execute() override { v.push_back(CreateShape()); };
	bool CanUndo() override { return true; }
	void Undo()    override
	{
		Shape* p = v.back();
		v.pop_back();
		delete p;
	}

	virtual Shape* CreateShape() = 0;
};


class AddRectCommand : public AddCommand
{
public:
	AddRectCommand(std::vector<Shape*>& v) : AddCommand(v) {}
	virtual Shape* CreateShape() override { return new Rect; }
};

class AddCircleCommand : public AddCommand
{
public:
	AddCircleCommand(std::vector<Shape*>& v) : AddCommand(v) {}
	virtual Shape* CreateShape() override { return new Circle; }
};

class DrawCommand : public ICommand
{
	std::vector<Shape*>& v;
public:
	DrawCommand(std::vector<Shape*>& v) : v(v) {}

	void Execute() override
	{
		for (auto p : v)
			p->Draw();
	};
	bool CanUndo() override { return true; }
	void Undo()    override
	{
		system("cls");
	}
};

//------------------------------------------
// �������� ������ ��� �����ϴ� ��ũ�� ����
class MacroCommand : public ICommand   // "COMPOSITE ����"
{
	std::vector<ICommand*> v;
public:
	void addCommand(ICommand* p) { v.push_back(p); }

	void Execute()
	{
		for (auto p : v) p->Execute();
	}
};
#include <stack>

int main()
{
	vector<Shape*> v;

	MacroCommand* mc1 = new MacroCommand;
	mc1->addCommand(new AddRectCommand(v));
	mc1->addCommand(new AddCircleCommand(v));
	mc1->addCommand(new DrawCommand(v));

	mc1->Execute();

	MacroCommand* mc2 = new MacroCommand;
	mc2->addCommand(new AddRectCommand(v));
	mc2->addCommand( mc1 ); //  ��ũ�� ������ �ٽ� ��ũ�� ���ɿ� ����.

	mc2->Execute();




	std::stack<ICommand*> cmd_stack;

	ICommand* pCmd = nullptr;


	while (1)
	{
		int cmd;
		cin >> cmd;

		if (cmd == 1)
		{
			pCmd = new AddRectCommand(v);
			pCmd->Execute();
			cmd_stack.push(pCmd);
		}
		else if (cmd == 2)
		{
			pCmd = new AddCircleCommand(v);
			pCmd->Execute();
			cmd_stack.push(pCmd);
		}
		else if (cmd == 9)
		{
			pCmd = new DrawCommand(v);
			pCmd->Execute();
			cmd_stack.push(pCmd);
		}
		else if (cmd == 0)
		{
			if (cmd_stack.empty() == false)
			{
				pCmd = cmd_stack.top();
				cmd_stack.pop();

				if (pCmd->CanUndo())
					pCmd->Undo();

				delete pCmd;
			}
		}
	}
}


