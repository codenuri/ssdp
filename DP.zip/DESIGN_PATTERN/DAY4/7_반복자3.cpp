#include <iostream>
using namespace std;


template<typename T> struct Node
{
	T  data;
	Node* next;
	Node(const T& d, Node* n) : data(d), next(n) {}
};



template<typename T> struct slist_enumerator 
{
	Node<T>* current = nullptr;
public:
	slist_enumerator(Node<T>* p) : current(p) {}

	// �̵� �� ��Ҿ�� �Լ��� �̸��� "�迭"�� ������� ��������.
	// �迭�̵� : ++p, ��Ҿ�� : *p

	inline T& operator*() { return current->data; }

	inline slist_enumerator<T>& operator++()
	{
		current = current->next; 
		return *this;
	}
};

template<typename T> class slist
{
	Node<T>* head = nullptr;
public:
	void push_front(const T& a) { head = new Node<T>(a, head); }
	T& front() { return head->data; }

	slist_enumerator<T>  begin() { return slist_enumerator<T>(head); }
};

int main()
{
	slist<int> s;
	s.push_front(10);
	s.push_front(30);
	s.push_front(40);

	slist_enumerator<int> p = s.begin();

	std::cout << *p << std::endl; // 40
	++p;
	std::cout << *p << std::endl; // 30
}




