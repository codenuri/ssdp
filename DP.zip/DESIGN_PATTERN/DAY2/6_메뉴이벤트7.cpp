// 6_�޴��̺�Ʈ7 - 1�� ������ ������..

#include <iostream>
#include <string>
#include <vector>
#include <conio.h>		// _getch() �������..
#include <functional>	// std::function<>, std::bind()
using namespace std;
using namespace std::placeholders; // _1, _2 ... 



class BaseMenu
{
	string title;
public:
	BaseMenu(string s) : title(s) {}
	string getTitle() const { return title; }
	virtual void command() = 0;
};

class PopupMenu : public BaseMenu
{
	vector<BaseMenu*> v;
public:
	PopupMenu(string s) : BaseMenu(s) {}

	void addMenu(BaseMenu* p) { v.push_back(p); }

	virtual void command()
	{
		while (1)
		{
			system("cls");

			int sz = v.size();

			for (int i = 0; i < sz; i++)
			{
				printf("%d. %s\n", i + 1, v[i]->getTitle().c_str());
			}

			printf("%d. �����޴��� �̵�\n", sz + 1);

			printf("�޴��� �����ϼ��� >>");
			int cmd;
			cin >> cmd;


			if (cmd < 1 || cmd > sz + 1)
				continue;


			if (cmd == sz + 1)
				break;

			v[cmd - 1]->command();

		}
	}
};
//--------------------------------------------
class MenuItem : public BaseMenu
{
	int id;
public:
	MenuItem(string s, int n) : BaseMenu(s), id(n) {}

	std::function<void()> handler = 0;

	virtual void command()
	{
		if (handler) handler();
	}
};

void foo()             { std::cout << "foo" << std::endl; }
void goo(int a, int b) { std::cout << "goo" << std::endl; }

class Camera
{
public:
	void take(int a) { std::cout << "Camera take" << std::endl; }
};
int main()
{
	MenuItem m1("AAA", 11);
	MenuItem m2("BBB", 12);
	MenuItem m3("CCC", 13);

	// foo, goo, Camera::take �� ���� m1, m2, m3�� ����� ������
	m1.handler = foo;
	m2.handler = std::bind(&goo, 0, 0);

//	Camera cam;
//	m3.handler = std::bind(&Camera::take, &cam, 0);

//	m3.handler = []() { std::cout << "lambda handler" << std::endl; };

	Camera cam2;

	m3.handler = [&cam2]() { cam2.take(1);  };

	m1.command();
	m2.command();
	m3.command();
}
// google.com ���� "c++ nana gui" ��� �˻��� ������









