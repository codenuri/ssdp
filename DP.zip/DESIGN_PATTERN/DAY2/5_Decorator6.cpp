#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
using namespace std;

class FileStream
{
	FILE* file;
public:
	FileStream(const char* s, const char* mode = "wt")
	{
		file = fopen(s, mode);
	}
	~FileStream() { fclose(file); }

	void Write(const char* buff)
	{
		printf("%s ����\n", buff);
	}
};
// Decorator6
int main()
{
	FileStream fs("a.tx");
	fs.Write("Hello");

	NetworkStream ns("127.120.0.1");
	ns.Write("Hello");

	PipeStream ps("A��� ���μ���");
	ps.Write("Hello");

}



