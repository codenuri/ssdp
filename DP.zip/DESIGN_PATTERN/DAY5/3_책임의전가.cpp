#define USING_GUI
#include "cppmaster.h"
#include <map>

class Window;
map<int, Window*> this_map;

class Window
{
	int handle;
public:
	void Create(string title)
	{
		handle = ec_make_window(msg_handler, title);
		this_map[handle] = this;
	}

	static int msg_handler(int hwnd, int msg, int a, int b)
	{
		Window* self = this_map[hwnd];

		switch (msg)
		{
		case WM_LBUTTONDOWN: self->OnLButtonDown(); break;
		case WM_KEYDOWN: self->OnKeyDown();	break;
		}
		return 0;
	}
	virtual void OnLButtonDown() { }
	virtual void OnKeyDown() { }
};

class MainFrame : public Window
{
public:
	virtual void OnLButtonDown() { cout << "LBUTTON" << endl; }
};

class ImageView : public Window
{
public:
	virtual void OnLButtonDown() { cout << "ImageView LBUTTON" << endl; }
};

int main()
{
	MainFrame w;
	w.Create("AA"); 
	
	ImageView img;
	img.Create("BB");

	ec_process_message();
}





