// 2_�޴�2
#include <iostream>
#include <string>
#include <vector>
#include <conio.h> 

// ��� �޴��� ��� Ŭ����
class BaseMenu
{
	std::string title;
public:
	BaseMenu(std::string s) : title(s) {}

	std::string getTitle() const { return title; }

	virtual void command() = 0;
};

// MenuItem

int main()
{

}




