﻿// 2_메뉴2
#include <iostream>
#include <string>
#include <vector>
#include <conio.h> 

// 모든 메뉴의 기반 클래스
class BaseMenu
{
	std::string title;
public:
	BaseMenu(std::string s) : title(s) {}

	std::string getTitle() const { return title; }

	virtual void command() = 0;
};

// MenuItem

int main()
{

}




