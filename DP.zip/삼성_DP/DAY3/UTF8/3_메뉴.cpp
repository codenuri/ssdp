﻿// 2_메뉴1.cpp  - 55 page
#include <iostream>
using namespace std;

int main()
{
	printf("1. 김밥\n");
	printf("2. 라면\n");
	printf("메뉴를 선택하세요 >> ");

	int cmd;
	cin >> cmd;

	switch (cmd)
	{
	case 1: break;
	case 2: break;
	}
	// 위코드의 문제점
	// 1. 새로운 메뉴를 추가하면 여러곳의 코드가 수정되어야 한다.
	// 2. 메뉴의 구조를 변경하기가 복잡하다.
}


