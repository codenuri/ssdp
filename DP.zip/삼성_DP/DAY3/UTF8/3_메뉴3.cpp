﻿#include <iostream>
#include <string>
#include <vector>
#include <conio.h> 

class BaseMenu
{
	std::string title;
public:
	BaseMenu(string s) : title(s) {}
	std::string getTitle() const { return title; }
	virtual void command() = 0;
};

class MenuItem : public BaseMenu
{
	int id;
public:
	MenuItem(std::string s, int n) : BaseMenu(s), id(n) {}

	virtual void command()
	{
		std::cout << getTitle() << " 선택됨" << std::endl;
		_getch();
	}
};
// 메뉴 선택시 "하위 메뉴"를 보여주는 메뉴
class PopupMenu : public BaseMenu
{
	std::vector<??*> v;
public:
	PopupMenu(std::string s) : BaseMenu(s) {}

	void addMenu(??* p) { v.push_back(p); }

	virtual void command() 
	{
	}
};

int main()
{
	MenuItem m1("김밥", 1);
	MenuItem m2("라면", 2);
}




