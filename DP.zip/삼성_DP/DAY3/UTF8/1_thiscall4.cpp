﻿#define USING_GUI
#include "cppmaster_gui.h""
#include <map>

void foo(int id)
{
	std::cout << "foo : " << id << std::endl;
}

int main()
{
	int id1 = ec_set_timer(1000, foo);
	int id2 = ec_set_timer(500, foo);

	ec_process_message(); // 종료되지 말고 타이머를 처리해 달라!
}




/*
class Clock
{
	string name;
public:
	Clock(string s) : name(s) {}

	void Start(int ms)
	{
	}

};

int main()
{
	Clock c1("AAA");
	Clock c2("\tBBB");

	c1.Start(1000); 
	c2.Start(500);  

	ec_process_message();
}
*/




