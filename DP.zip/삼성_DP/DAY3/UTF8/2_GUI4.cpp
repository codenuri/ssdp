﻿#define USING_GUI
#include "cppmaster_gui.h"
#include <map>
#include <vector>

class CWnd;
map<int, CWnd*> this_map;


struct MSG_MAP
{
	int message;			// 메세지 번호
	void(CWnd::*handler)(); // 처리할 함수
};

class CWnd
{
	int mHandle;
public:
	void Create()
	{
		mHandle = ec_make_window(foo);  
		this_map[mHandle] = this;
	}

	virtual MSG_MAP* GetMessageMap() { return 0; }


	static int foo(int hwnd, int msg, int a, int b)
	{
		CWnd* const pThis = this_map[hwnd];
		if (pThis == 0) return 0;

		MSG_MAP* arr = pThis->GetMessageMap();
		if (arr == 0) return 0;

		for (; arr->handler != 0; arr++)
		{
			if (msg == arr->message)
			{
				void(CWnd::*f)() = arr->handler;
				(pThis->*f)();  
			}
		}
		return 0;
	}
};

class MyWindow : public CWnd
{
public:
	void LButtonDown() { cout << "LBUTTON" << endl; }

	void foo() { cout << "foo" << endl;}

	virtual MSG_MAP* GetMessageMap()
	{
		typedef void(CWnd::*FUNC)();

		static MSG_MAP arr[] = {
			{ WM_LBUTTONDOWN, (FUNC)&MyWindow::LButtonDown},
			{ WM_KEYDOWN,     (FUNC)&MyWindow::foo},
			{ 0, 0}
		};

		return arr;
	}
};




int main()
{
	MyWindow w;
	w.Create();

	ec_process_message();
}

