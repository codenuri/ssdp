﻿// 2_메뉴2
#include <iostream>
#include <string>
#include <vector>
#include <conio.h> // _getch() 사용위해..
// 59 page 아래 부분
// Composite 패턴(포함 패턴)
// 복합 객체는 개별 객체 뿐 아니라 복합 객체 자신도 보관한다.
// 재귀적 포함을 통한 복합객체 만들기!!

// 복합 객체와 개별 객체는 동일 기반 클래스가 필요


// 복합객체와 개별객체는 사용법이 동일하다.
// => 메뉴 종류에 상관없이 선택시 command() 함수 호출
//    command() 함수는 기반 클래스에 있어야 한다.



// 모든 메뉴의 기반 클래스
class BaseMenu
{
	std::string title;
public:
	BaseMenu(std::string s) : title(s) {}

	std::string getTitle() const { return title; }

	// 모든 메뉴는 선택될수 있다.. 구현은 파생클래스에서!!
	virtual void command() = 0;
};

class MenuItem : public BaseMenu
{
	int id;
public:
	MenuItem(std::string s, int n) : BaseMenu(s), id(n) {}

	virtual void command()
	{
		std::cout << getTitle() << " 선택됨" << std::endl;
		_getch();
	}
};
// 메뉴 선택시 "하위 메뉴"를 보여주는 메뉴
class PopupMenu : public BaseMenu
{
	std::vector<BaseMenu*> v;
public:
	PopupMenu(string s) : BaseMenu(s) {}

	void addMenu(BaseMenu* p) { v.push_back(p); }

	virtual void command()
	{
		while (1)
		{
			system("cls");

			int sz = v.size(); // 하위 메뉴 갯수

			for (int i = 0; i < sz; i++)
			{
				printf("%d. %s\n", i + 1, v[i]->getTitle().c_str());
			}

			printf("%d. 상위메뉴로 이동\n", sz + 1);

			printf("메뉴를 선택하세요 >>");
			int cmd;
			cin >> cmd;


			if (cmd < 1 || cmd > sz + 1) // 잘못된 입력
				continue;


			if (cmd == sz + 1) // 상위 메뉴로 선택
				break;



			// 선택된 메뉴를 실행한다.
			// MenuItem 인지 PopupMenu 인지 조사할 필요 없다.
			v[cmd - 1]->command(); // 다형성

		}
	}
};

int main()
{
	PopupMenu* menubar = new PopupMenu("MENUBAR");
	PopupMenu* p1 = new PopupMenu("색상 변경");
	PopupMenu* p2 = new PopupMenu("해상도 변경");

	menubar->addMenu(p1);
	menubar->addMenu(p2);

	p1->addMenu(new MenuItem("RED",   11));
	p1->addMenu(new MenuItem("GREEN", 12));
	p1->addMenu(new MenuItem("BLUE",  13));
	p1->addMenu(new MenuItem("BLACK", 14));

	// 시작하려면어떻게 할까요 ?
}










