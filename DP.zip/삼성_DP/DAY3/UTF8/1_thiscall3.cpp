﻿#include <iostream>
#include <Windows.h>

DWORD __stdcall foo(void* p)
{
	std::cout << "foo" << std::endl;
	return 0;
}

int main()
{
	CreateThread(0, 0, foo, "A", 0, 0); // 윈도우에서 스레드 만드는 함수
									    // 리눅스 : pthread_create()
	getchar();
}



/*
// 스레드 개념을 객체지향으로 설계해 봅시다.
class Thread
{
public:
	void run() {  }

	virtual void threadLoop() {  } // threadLoop( Thread* const this)
};

class MyThread : public Thread
{
public:
	virtual void threadLoop() { cout << "threadLoop" << endl; }
};

int main()
{
	MyThread t;
	t.run(); 

	getchar();
}

*/

