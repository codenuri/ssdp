#define USING_GUI
#include "cppmaster_gui.h"
#include <map>
#include <vector>

class CWnd;
map<int, CWnd*> this_map;

class CWnd
{
	int mHandle;

	//------------------------------------------
	vector<CWnd*> child_vector; // �ڽ��� �������̴�.
	CWnd* parent; // �θ�� �Ѹ��̴�.
public:
	CWnd() : parent(0) {}
	//---------------------------------------

	void addChild(CWnd* p)
	{
		p->parent = this;

		child_vector.push_back(p);

		// C�� ����ؼ� �ڽ� �����츦 ���δ�.
		ec_add_child(this->mHandle, p->mHandle);
	}



	void Create()
	{
		mHandle = ec_make_window(foo, "A");
		this_map[mHandle] = this;
	}

	static int foo(int hwnd, int msg, int a, int b)
	{
		CWnd* const pThis = this_map[hwnd];

		switch (msg)
		{
		case WM_LBUTTONDOWN: pThis->LButtonDown(); break;
		case WM_KEYDOWN:     pThis->KeyDown(); break;
		}
		return 0;
	}
	virtual void LButtonDown() {}
	virtual void KeyDown() {}
};


class MyWindow : public CWnd
{
public:
	void LButtonDown() { cout << "LBUTTON" << endl; }
};

class ImageView : public CWnd
{
public:
	void LButtonDown() { cout << "ImageView LBUTTON" << endl; }
};

int main()
{
	MyWindow w;
	w.Create();

	ImageView w2;
	w2.Create();

	w.addChild(&w2);

	IoProcessMessage();
}



