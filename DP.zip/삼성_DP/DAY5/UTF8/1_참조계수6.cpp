﻿#include <iostream>
#include <vector>
using namespace std;


template<typename T>
class RefBase
{
	mutable int refCount = 0;
							 
public:
	void AddRef() const { ++refCount; }

	void Release() const  
	{
		if (--refCount == 0)
			delete static_cast<const T*>(this); 
	}

protected:
	~RefBase() { cout << "RefBase 파괴" << endl; }
};



class Truck : public RefBase< Truck >
{
public:
	~Truck() { std::cout << "~Truck" << std::endl; }
	void Go() { std::cout << "Truck Go" << std::endl; }
};

// AddRef와 Release를 자동으로 수행하는 스마트 포인터를 도입해 봅시다.
template<typename T> class AutoPtr
{
	T* obj;
public:
	AutoPtr(T* p = nullptr)		  : obj(p) { if (obj) obj->AddRef();  }
	AutoPtr(const AutoPtr<T>& ap) : obj(ap.obj) { if (obj) obj->AddRef(); }
	~AutoPtr() { if (obj) obj->Release();  }

	// 스마트 포인터의 기본 -> 와 * 연산자 재정의
	T* operator->() { return obj; }
	T& operator*()  { return *obj; }
};

int main()
{
	AutoPtr<Truck> p1 = new Truck; // AutoPtr<Truck> p1(new Truck)
	AutoPtr<Truck> p2 = p1;
	p1->Go();
}

/*
// 스마트 포인터 도입전
// raw pointer : 객체가 아닙니다. 생성/소멸 과정에 작업을 추가 할수 없습니다.
int main()
{
	Car* p1 = new Car;
	p1->AddRef();			// 규칙 1. 객체 생성시 참조계수 증가

	Car* p2 = p1;
	p2->AddRef();			// 규칙 2. 객체의 주소를 복사하면 참조계수 증가

	// 규칙 3. 포인터 사용후에는 참조계수 감소
	p2->Release();
	p1->Release();
}
*/





