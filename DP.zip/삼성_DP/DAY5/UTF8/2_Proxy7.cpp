﻿#define USING_GUI
#include "cppmaster.h"
#include "ICalc.h"

template<typename T> class AutoPtr
{
	T* obj;
public:
	AutoPtr(T* p = nullptr) : obj(p) { if (obj) obj->AddRef(); }
	AutoPtr(const AutoPtr<T>& ap) : obj(ap.obj) { if (obj) obj->AddRef(); }
	~AutoPtr() { if (obj) obj->Release(); }

	T* operator->() { return obj; }
	T& operator*() { return *obj; }
};


int main()
{
	void* addr = ec_load_module("CalcProxy.dll");

	typedef ICalc*(*F)();
	F f = (F)ec_get_function_address(addr, "CreateProxy");
	//--------------------------------------------
	AutoPtr<ICalc> pCalc = f(); 

	cout << pCalc->Add(1, 2) << endl;
	cout << pCalc->Sub(1, 2) << endl;
}

// 위 구조는 아주 널리 사용됩니다. : MS의 "COM(ActiveX)" 기술,
//									IBM CORBA
//									안드로이드 프레임워크, AUTOSAR(자동차OS) 등이 모두 위구조입니다.





