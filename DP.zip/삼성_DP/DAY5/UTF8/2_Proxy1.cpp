﻿
// VS 한개를 더실행하세요.. 

// SERVER 프로젝트 열어 두세요.
// x86, Debug로 설정하세요

// Windows SDK 버전 설정하세요.




/*
// 채팅창 질문 답 1
Car* p1 = new Car;
Car* p2 = p1;    // 2개의 포인터가 한개의 객체를 가리킬때
Car* temp = p1; // 이런 코드가 있어도.. 아래 문제는 해결되지 않습니다.
delete p1;		 // p1을 사용하던 사람이 이렇게 delete 하면	

p2->Go();	// p2를 사용하던 사람의 이 코드는 오류입니다.
			// 이문제를 해결하기 위해서 "참조계수"를 사용합니다.

// 채팅창 질문 답 2
// 기반 클래스에 다른 가상함수가 많이 있다면.. 소멸자를 추가로 가상으로 하는 것은 오버헤드가 크지않고
// CRTP를 사용하면 Upcasting 기술 활용이 어렵습니다.
std::vector<RefBase*> v; // CRTP가 없다면 이렇게 할수 있습니다.
						 // CRTP를 사용하면 RefBase가 템플릿 이므로 이 코드가 안됩니다.
*/

// 77 page

// Server 폴더에 있는 "cppmaster.h" 파일을 DAY5폴더에 복사(덮어쓰기 하세요)해 놓으세요.


#define USING_GUI
#include "cppmaster.h"

int main()
{
	// 1. 서버의 핸들을 얻어 옵니다.
	int server = ec_find_server("Calc");

	cout << "서버 번호 : " << server << endl;

	// 2. 서버에 명령코드와 파라미터를 전달합니다.
	int n1 = ec_send_server(server, 1, 10, 20);
	int n2 = ec_send_server(server, 2, 10, 20);

	cout << n1 << ", " << n2 << endl;

}







