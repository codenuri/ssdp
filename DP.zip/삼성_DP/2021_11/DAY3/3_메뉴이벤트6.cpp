﻿#include <iostream>
#include <functional>
using namespace std::placeholders;

class Camera
{
public:
	void take() { std::cout << "Camera take" << std::endl; }
};

void foo(int a) { std::cout << "foo : " << a << std::endl; }
void goo(int a, int b) { std::cout << "goo : " << a << b << std::endl; }
void hoo(int a, int b, int c) { std::cout << "hoo : " << a << b << c << std::endl; }

int main()
{
	void(*pf)(int) = &foo;
	pf(10); // ok.. foo(10);

	pf = &goo; // ???

}


