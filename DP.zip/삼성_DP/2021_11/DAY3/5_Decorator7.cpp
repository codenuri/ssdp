﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
using namespace std;


struct Stream
{
	virtual void Write(const char*) = 0;
	virtual ~Stream() {}
};

class FileStream : public Stream
{
	FILE* file;
public:
	FileStream(const char* s, const char* mode = "wt")
	{
		file = fopen(s, mode);
	}
	~FileStream() { fclose(file); }

	void Write(const char* buff)
	{
		printf("%s 쓰기\n", buff);
	}
};

// 파일및 다양한 스트림 클래스에 기능을 추가하는 클래스(Decorator)를 제공합니다.

class ZipStream : public Stream  // 압축기능을 가진 Decorator
{
	Stream* stream;		
public:
	ZipStream(Stream* s) : stream(s) {}

	void Write(const char* s) override
	{
		// 전달된 데이타를 압축합니다.
		std::string temp = s;
		temp = temp + " 압축됨";

		// 압축한 데이타를 원래 객체(FileStream) 에 씁니다.
		stream->Write(temp.c_str());
	}
};

class EncrpytStream : public Stream
{
	Stream* stream;
public:
	EncrpytStream(Stream* s) : stream(s) {}

	void Write(const char* s) override
	{
		std::string temp = s;
		temp = temp + " 암호화됨";

		stream->Write(temp.c_str());
	}
};
int main()
{
	FileStream f("a.txt");
	f.Write("Hello");		// 그냥 출력

	EncrpytStream es(&f);
	es.Write("Hello");		// 암호화후 출력

	ZipStream zs(&es);
	zs.Write("Hello");

	// FileStream, NetworkStream, PipeStream : 저장소 ( Backing Store )
	// ZipStream, EncrpytStream				: 저장소를 꾸미는 Decorator(기능추가 객체)

	// 저장소와 기능추가 객체는 사용법이 동일하다.(동일 인터페이스 )
}

// 재귀적 포함을 사용하는 디자인 패턴은 2가지 입니다.
// 2개가 클래스 다이어그램이 유사합니다.

// 왜 재귀적 포함(자신이 자신을 포함)을 사용하는가 ?
// 의도에 따라 패턴이름이 정해 접니다.

// Composite : 복합객체(객체가 여러개의 객체를 포함)만들기 위해
// Decorator : 기존 객체에 기능 추가를 위해서






