﻿#include <iostream>
#include <string>
#include <vector>
#include <conio.h> 

// MenuItem

int main()
{

}




