﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>

class FileStream
{
	FILE* file;
public:
	FileStream(const char* s, const char* mode = "wt")
	{
		file = fopen(s, mode);
	}
	~FileStream() { fclose(file); }

	void Write(const char* buff)
	{
		printf("%s 쓰기\n", buff);
	}
};

int main()
{
	// C 언어의 문제점 : 항상 사용자가 직접 자원을 관리해야 한다.
	FILE* f = fopen("a.txt", "wt");
	fclose(f);
}



