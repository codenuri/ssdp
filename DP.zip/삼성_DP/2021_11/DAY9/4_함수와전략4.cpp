﻿#include <iostream>
#include <algorithm> 

inline bool cmp1(int a, int b) { return a < b; }
inline bool cmp2(int a, int b) { return a > b; }

struct Less   { inline bool operator()(int a, int b) { return a < b; }};
struct Greater{	inline bool operator()(int a, int b) { return a > b; }};

int main()
{
	int x[10] = { 1,3,5,7,9,2,4,6,8,10 };

	// sort의 모든 인자는 템플릿 입니다.

	// 1. 비교정책으로 일반 함수를 사용하는 경우

	std::sort(x, x + 10, cmp1);
	std::sort(x, x + 10, cmp2);


	// 2. 비교정책으로 함수 객체를 사용하는 경우

	Less    f1;
	Greater f2;
	std::sort(x, x + 10, f1);
	std::sort(x, x + 10, f2);
}



