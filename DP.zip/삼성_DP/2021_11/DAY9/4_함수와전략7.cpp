﻿#include <iostream>
#include <string>

struct Point
{
	int x = 0;
	int y = 0;

	Point() = default;
	Point(int x, int y) :x(x), y(y) {}
};

template<typename T> 
const T& Max(const T& a, const T& b)
{
	return a < b ? b : a;
}

int main()
{
	int n1 = 10, n2 = 20;
	std::cout << Max(n1, n2) << std::endl;

	Point p1(1, 1);
	Point p2(2, 2);

	Point p3 = Max(p1, p2);
}
