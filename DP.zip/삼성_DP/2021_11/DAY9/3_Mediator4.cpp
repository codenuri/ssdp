#include <iostream>
#include <string>
#include <map>
#include <functional>
#include <vector>
using namespace std;
using namespace std::placeholders;


class NotificationCenter
{
	using HANDLER = std::function<void(void*)>; 

	std::map<std::string, std::vector<HANDLER> > notif_map;
public:
	void addObserver(std::string key, HANDLER h)
	{
		notif_map[key].push_back(h);
	}
	void postNotificationWithName(std::string key, void* param)
	{
		for (auto f : notif_map[key] )
			f(param);					
	}
};
void foo(void* p)        { cout << "foo : " << (int)p << endl; }
void goo(void* p, int a) { cout << "goo : " << (int)p << endl; }

int main()
{
	NotificationCenter nc;

	nc.addObserver("LOWBATTERY", &foo);
	nc.addObserver("LOWBATTERY", std::bind( &goo, _1, 0));
	nc.addObserver("LOWBATTERY", [](void* p) { std::cout << "���ٵ��" << std::endl; } );

	nc.postNotificationWithName("LOWBATTERY", (void*)30);
}


