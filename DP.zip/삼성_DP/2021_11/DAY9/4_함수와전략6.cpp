﻿#include <iostream>

struct Point
{
	int x;
	int y;
};
int main()
{
	int n = 10;
	int* p = &n;


}
