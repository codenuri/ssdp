﻿#include <iostream>
#include <functional>

class Dialog
{
public:
	void Close() { std::cout << "close" << std::endl; }
};
void foo() { std::cout << "foo" << std::endl; }

int main()
{
	void(*f1)() = &foo;
	void(Dialog::*f2)() = &Dialog::Close;

	Dialog dlg;

	f1();
	(dlg.*f2)();

}
