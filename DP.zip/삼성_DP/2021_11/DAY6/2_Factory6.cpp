﻿// 2_객체생성정리 - 118 page
class Rect
{
};

// 객체를 만드는 방법

// 1. new Rect   

// 2. Rect::Create()
				
// 3. r->Clone();  

// 4. factory.Create() 




