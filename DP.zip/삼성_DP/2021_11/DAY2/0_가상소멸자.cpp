#include <iostream>

class Base
{
public:
	Base() {}
	~Base(){}
};

class Derived : public Base
{
public:
	Derived()  { std::cout << "Derived()"  << std::endl;}
	~Derived() { std::cout << "~Derived()" << std::endl;}
};

int main()
{
	{
		Derived d;
	}
	std::cout << "-----------------" << std::endl;
	Derived* p1 = new Derived;
	delete p1;
	std::cout << "-----------------" << std::endl;
}