﻿// 접근변경자2.cpp
#include <list>
#include <deque>
#include <vector>
using namespace std;

// STL 에 list 가 있는데,, 사용자가 Stack 을 요구합니다.
// 1. Stack 처음부터 만들자
// 2. list 를 스택처럼 보이게 변경하자.



int main()
{
}







