﻿// github.com/codenuri/samsung  에 소스 올리 겠습니다.

#include <iostream>

struct BM	// Base Member라는 의미
{
	BM()  { std::cout << "BM()" << std::endl; }
	~BM() { std::cout << "~BM()" << std::endl; }
};

struct DM	// Derived Member 라는 의미
{
	DM()  { std::cout << "DM()" << std::endl; }
	~DM() { std::cout << "~DM()" << std::endl; }
};
//=======================================
struct Base
{
	BM bm;

	// 사용자 코드	컴파일러가 변경한 코드
	Base()			// Base() : bm()
	{
		std::cout << "Base()" << std::endl; 
	}


	~Base() { std::cout << "~Base()" << std::endl; }
};

//Base b;


struct Derived : public Base
{
	DM dm;

	// 사용자가 만든 코드		// 컴파일러가 변경한 코드
	Derived()				// Derived() : Base(), dm()
	{
		std::cout << "Derived()" << std::endl; 
	}
	~Derived() { std::cout << "~Derived()" << std::endl; }
};

int main()
{
	Derived d;
}
// 핵심
// 1. 기반 클래스 생성자가 먼저 호출되고
// 2. 멤버 데이타의 생성자 호출
// 사용자가 순서를 변경할수 없다.


