#include <iostream>
#include <functional>

struct Point
{
	int x, y;

	Point() = default;
	Point(int a, int b) : x(a), y(b) {}
};

struct identity
{
	template<typename T> 
	T& operator()(T& obj) { return obj; }
};

// ���� ���� ���Դ� Max�� ������ ���ô�.
template<typename T, typename Proj = identity, typename Comp = std::less<void> > 
const T& Max(const T& a, const T& b, Comp comp = {}, Proj f = {})
{
	return std::invoke(comp, std::invoke(f, a), std::invoke(f, b)) ? b : a;
}

int main()
{
	Point p1(1, 1);
	Point p2(2, 2);
	Point p3 = Max(p1, p2, {}, &Point::y);
}