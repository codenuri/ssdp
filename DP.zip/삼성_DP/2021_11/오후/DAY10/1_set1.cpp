﻿#include <iostream>
#include <set> // 대부분 RB Tree 로 구현 합니다.
/*
// STL set 의 설계 원리
template<typename T,                 // 저장하는 요소 타입
	     typename Pr = std::less<T>, // 요소 비교에 사용할 함수 객체 (less : < )
		 typename Alloc = std::allocator<T> > // 메모리 할당
class set
{
	Pr pr;
	Alloc ax;
public:
	void insert(const T& elem)
	{
//		if ( root->elem < elem ) // 이렇게 했다면 비교연산을 교체 할수 없습니다.
		if (pr(root->elem, elem))
			move right child;

		else if (pr(elem, root->elem))
			move left child;
		
		else
			이미 요소가 있다. insert 실패.

	}
};
*/

int main()
{
//	std::set<int> s;

	std::set<int, std::greater<int> > s;

	s.insert(20);
	s.insert(10);
	s.insert(30);
	s.insert(15);
	s.insert(25);

	for (auto e : s)
		std::cout << e << ", ";

	std::cout << std::endl;
}
