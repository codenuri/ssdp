﻿#include <iostream>
#include <list>
#include <vector>

/*
void print_first_element(std::vector<int>& v)
{
	int n = v.front();

	std::cout << n << std::endl;
}
*/

/*
template<typename T> 
void print_first_element(std::vector<T>& v)
{
	T n = v.front();

	std::cout << n << std::endl;
}
*/

template<typename T>
void print_first_element(T& v)
{
	// T : list<double> 입니다.

	// T::value_type => list<double>::value_type => double

	// 아래 ? 에는 현재 상태에서는 double 이 필요 합니다.

	typename T::value_type n = v.front();

	// T::"이름"           ==> "이름"을 static 멤버데이타 또는 enum 상수로 취급
	// typename T::"이름"  ==> "이름"을 타입의 이름으로 해석해 달라.

	std::cout << n << std::endl;
}



int main()
{
//	std::vector<int>    c = { 1,2,3,4,5 };
//	std::vector<double> c = { 1,2,3,4,5 };
	std::list<double>    c = { 1,2,3,4,5 };

	print_first_element(c);
}

// 템플릿 기반 컨테이너에서는 컨테이너가 저장하는 타입이 있습니다.
// 그 타입을 외부 에서 알고 싶을때가 있습니다.
// 그래서, STL을 아래 처럼 만들었습니다.
template<typename T> class list
{
public:
//	typedef T value_type; // C++98
	using value_type = T; // C++11 이후

	// ...다른 멤버들..
};

list<int> s = { 1,2,3,4,5 };
list<int>::value_type n = s.front();