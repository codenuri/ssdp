﻿// empty1.cpp
#include <iostream>
#include <thread>
#include <mutex>

// 핵심 : mutex 에는 lock() 뿐 아니라 try_lock()도 있습니다.

std::mutex m;

void foo()
{
//	m.lock();     // lock 을 획득하지 못하면 대기
	
	if (m.try_lock()) // lock 을 획득하지 못하면 false 반환
	{
		//....

		m.unlock();
	}
}

int main()
{
	std::thread t(foo);
	t.join();
}
