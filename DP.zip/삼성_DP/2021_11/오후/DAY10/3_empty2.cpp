﻿#include <iostream>
#include <thread>
#include <mutex>


template<typename T> class lock_guard
{
	T& mtx;
public:
	lock_guard(T& m) : mtx(m) { mtx.lock(); }
	~lock_guard()             { mtx.unlock(); }
};

std::mutex m;

void foo()
{
//	m.lock();
//	m.unlock();

	// 위처럼 직접 lock/unlock 하지 말고
	// 아래처럼 lock_guard같은 도구를 사용하세요
	lock_guard<std::mutex> g(m);

}

void goo()
{
	if (m.try_lock())
	{
		// 이미 lock 을 획득했는데...
		// unlock 만 자동으로 하고 싶다.
		// m.unlock(); 이렇게 하지 말고.

		lock_guard<std::mutex> g(m); // 이렇게 하면 생성자에서 또 m.lock() 하게 된다.
							// 결론 : lock()을 수행하지 않는 또 다른 생성자가 필요 하다.
	}
}


int main()
{
	std::thread t(foo);
	t.join();
}










