﻿#include <iostream>
#include <string>

// less 함수 객체 : 2개의 객체에 대한 "<" 연산을 수행하는 함수 객체

// 1. template 으로 해야 한다.
// 2. () 연산자는 상수 멤버 함수가 되어야 한다.
// 3. inline, constexpr 등을 붙이면 성능향상에 도움이 된다.

template<typename T> struct less
{
	constexpr inline bool operator()(const T& a, const T& b) const 
	{
		return a < b;
	}
};

template<typename T> void foo(const T& f)
{
	bool b = f(10, 20); // f.operator()(10,20)
}

int main()
{
	int n1 = 10, n2 = 10;
	std::string s1 = "A", s2 = "BB";

	less<int> fi;
	less<std::string> fs;

	bool b1 = fi(n1, n2);
	bool b2 = fs(s1, s2);

	foo(fi);
}
