﻿#include <iostream>
#include <set>
#include <string>

// set에 사용자 정의 타입을 값으로 보관하기

struct People
{
	std::string name;
	int age;

	People(std::string name, int age) : name(name), age(age) {}
};

struct PeopleCompare
{
	inline bool operator()(const People& p1, const People& p2) const
	{
		return p1.age < p2.age;
	}
};

int main()
{
//	std::set<People> s; // std::set<People, std::less<People>, std::allocator<People>>

//	std::set<People, People객체 2개의 크기를 비교하는 함수객체 > s;

	std::set<People, PeopleCompare > s;

	s.insert(People("kim", 20));
	s.insert(People("lee", 10));
	s.insert(People("park", 24));
	s.insert(People("choi", 30));



}

