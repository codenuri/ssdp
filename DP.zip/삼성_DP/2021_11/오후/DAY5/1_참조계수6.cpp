﻿#include <iostream>
#include <vector>

class RefCount
{
	mutable int refCount = 0;
public:
	void AddRef() const { ++refCount; }

	void Release() const   
	{
		if (--refCount == 0)
			delete this; 
	}
protected:
	virtual ~RefCount() {  }
};
class Truck : public RefCount
{
public:
	~Truck() { std::cout << "~Truck" << std::endl; }

	void Go() { std::cout << "Truck Go" << std::endl; }
};

// 객체의 참조계수 관련 함수를 자동으로 호출하는 스마트 포인터
template<typename T>
class AutoPtr
{
	T* obj;
public:
	AutoPtr(T* p = nullptr)    : obj(p)      { if (obj) obj->AddRef(); }
	AutoPtr(const AutoPtr& ap) : obj(ap.obj) { if (obj) obj->AddRef(); }
	~AutoPtr() { if (obj) obj->Release(); }

	// 스마트 포인터의 핵심
	// -> 와 * 연산자를 재정의해서 포인터 처럼 보이게 합니다.
	T* operator->() { return obj; }
	T& operator*()  { return *obj; }
};

int main()
{
	AutoPtr<Truck> p1 = new Truck; // AutoPtr<Truck> p1 ( new Truck) 
	AutoPtr<Truck> p2 = p1;

	// p1, p2는 객체지만, 포인터 처럼 사용가능해야 합니다.
	p1->Go();
	(*p1).Go();

//	Truck* p1 = new Truck;
//	p1->AddRef();
//	Truck* p2 = p1;
//	p2->AddRef();
//	p2->Release();
//	p1->Release();
}
// 파이썬 코드
// n1 = 10
// n2 = n1 





