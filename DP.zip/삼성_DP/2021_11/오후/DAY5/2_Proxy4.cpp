﻿#define USING_GUI
#include "cppmaster.h"

// ICalc.h 만들고 아래 인터페이스 넣으세요
struct ICalc
{
	virtual int Add(int a, int b) = 0;
	virtual int Sub(int a, int b) = 0;

	virtual ~ICalc() {}
};

class Calc : public ICalc
{
	int server;
public:
	Calc() { server = ec_find_server("Calc"); }

	int Add(int a, int b) { return ec_send_server(server, 1, a, b); }
	int Sub(int a, int b) { return ec_send_server(server, 2, a, b); }
};

// 위에 있는 Proxy 클래스(Calc)는 누가 만들까요 ?
// 1. 서버 제작자 ======> 정답
// 2. 클라이언트 제작자

int main()
{
	// 아래처럼 만들면 클라이언트 제작자와 Proxy 사이에
	// 강한 결합이 됩니다.
	// 새로운 Proxy Class가 나오면 아래 코드는 수정되어야합니다.
	// OCP를 만족할수 없습니다.
//	Calc* pCalc = new Calc;

	// Proxy 사용시 약한결합을 사용해야 합니다.
	// 즉, 인터페이스 이름만 사용해야 합니다.
	ICalc* pCalc = new ? ;


	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ",  " << n2 << std::endl;
}







