﻿#define USING_GUI
#include "cppmaster.h"

#include "ICalc.h"

int main()
{
	void* addr = ec_load_module("calcproxy.dll");
	using PF = ICalc * (*)();
	PF f = (PF)ec_get_function_address(addr, "CreateProxy");

	//==============================
	ICalc* pCalc = f(); 

	pCalc->AddRef(); // 이렇게 사용하고 싶으면
					 // AddRef()는 반드시 ICalc에도 있어야 한다.


	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ",  " << n2 << std::endl;

	pCalc->Release(); // 이순간 참조계수가 0이 되므로 Proxy 가 안전하게 파괴 됩니다.
}







