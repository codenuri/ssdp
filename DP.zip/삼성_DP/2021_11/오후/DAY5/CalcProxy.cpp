#define USING_GUI
#include "cppmaster.h"
#include "ICalc.h"
#include <atomic>

class Calc : public ICalc
{
	int server;
	
	mutable std::atomic<int> refCount{ 0 };
public:

	void AddRef() const { ++refCount; }

	void Release() const
	{
		if (--refCount == 0)
			delete this;
	}

	~Calc() { std::cout << "Calc Proxy �ı�" << std::endl; }


	Calc() { server = ec_find_server("Calc"); }

	int Add(int a, int b) { return ec_send_server(server, 1, a, b); }
	int Sub(int a, int b) { return ec_send_server(server, 2, a, b); }
};

extern "C" __declspec(dllexport)
ICalc* CreateProxy()
{
	return new Calc;
}

// cl CalcProxy.cpp /LD /link user32.lib  gdi32.lib   kernel32.lib




