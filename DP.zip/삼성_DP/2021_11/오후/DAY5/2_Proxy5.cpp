﻿#define USING_GUI
#include "cppmaster.h"

// Client 제작자는 서버 제작자에게 2개의 파일을 받아야 합니다.
// 1. ICalc.h       : 인터페이스가 있는 헤더 파일
// 2. calcproxy.dll : proxy 코드가 있는 DLL 파일

#include "ICalc.h"

int main()
{
	// 1. 동적 모듈(DLL) Load
	void* addr = ec_load_module("calcproxy.dll");
					// linux : dlopen()   windows : LoadLibrary

	// 2. 동적 모듈에 있는 약속된 함수 찾기
	using PF = ICalc* (*)(); // typedef ICalc*(*PF)();

	PF f = (PF)ec_get_function_address(addr, "CreateProxy");
					// linux : dlsym()     windows : GetProcAddress()

	// 3. 해당 함수를 호출해서 proxy 객체 생성
	ICalc* pCalc = f();


	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ",  " << n2 << std::endl;
}







