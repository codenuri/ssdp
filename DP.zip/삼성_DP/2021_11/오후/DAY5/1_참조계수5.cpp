﻿#include <iostream>
#include <vector>
// 참조 계수 기능을 제공하는 기반 클래스
class RefCount
{
	mutable int refCount = 0;
public:
	void AddRef() const { ++refCount; }

	void Release() const   // void Release( RefCount* this)
	{
		if (--refCount == 0)
			delete this; // this가 RefCount* 이므로 
						// "delete 기반 클래스타입" 모양입니다.
						// 소멸자가 반드시 가상함수 이어야 합니다.
	}
protected:
	virtual ~RefCount() {  }
};
// 이제 참조계수 기능이 필요 하면 "RefCount" 로 부터 상속 받으면 된다.
class Truck : public RefCount
{
public:
	~Truck() { std::cout << "~Truck" << std::endl; }
};
int main()
{
	// Truck 객체도 참조계수로 관리하고 싶다.
	Truck* p1 = new Truck;

	p1->AddRef();
	p1->Release();
}






