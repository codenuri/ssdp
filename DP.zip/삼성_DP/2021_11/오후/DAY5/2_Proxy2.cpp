﻿#define USING_GUI
#include "cppmaster.h"

// proxy : 기존의 요소를 대신하는 클래스
// remote proxy : 원격지 서버를 대신하는 클래스

// 서버를 대신하는 클래스를 설계해 봅시다.
class Calc
{
	int server;
public:
	Calc() { server = ec_find_server("Calc"); }

	int Add(int a, int b) { return ec_send_server(server, 1, a, b); }
	int Sub(int a, int b) { return ec_send_server(server, 2, a, b); }
};

// 장점
// 1. 클라이언트 제작자는 IPC를 알지 못해도 된다.
// 2. 자주 사용되는 요청에 대해서는 "cache" 등을 기술을 사용할수도 있다.

// IPC 용어
// Proxy : 함수 호출을 명령 코드로 변경해서 서버에 전달 ( Add() => "1" => 서버)
// Stub  : 도착한 명령 코드를 함수 호출로 변경 ( "1" => server.Add())
//			서버 프로젝트의 "dispatch 함수"

int main()
{
	// 서버에 접속하려면
	// 서버를 대신하는 Calc Proxy 를 사용하면 됩니다.
	Calc* pCalc = new Calc;
	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ",  " << n2 << std::endl;
}







