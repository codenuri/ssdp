﻿// 6_Bridge1 - 90 page
#include <iostream>

// 모든 MP3 제품의 인터페이스
struct IMP3
{
	virtual void Play() = 0;
	virtual void Stop() = 0;
	virtual ~IMP3() {}
};
class IPod : public IMP3
{
public:
	void Play() { std::cout << "Play MP3 with IPod" << std::endl; }
	void Stop() { std::cout << "Stop" << std::endl; }
};
class People
{
public:
//	void Use(IPod* p) // 교체 불가능한 경직된 디자인
	void Use(IMP3* p) // 교체 가능한 유연한 디자인. OCP 만족
	{
		p->Play();
		p->Stop();

		// 새로운 요구 사항이 생겼다.
		p->PlayOneMinute(); // 1분 미리 듣기가 필요 하다.
						// 인터페이스 변경이 필요 하다. 그런데,, 인터페이스 변경은 너무 큰 일이다.
						// "인터페이스 불변의 법칙"
	}
};
int main()
{
	People p;
	IPod pod;
	p.Use(&pod);
}


