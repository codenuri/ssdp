﻿#define USING_GUI
#include "cppmaster.h"

#include "ICalc.h"

int main()
{
	void* addr = ec_load_module("calcproxy.dll");
	using PF = ICalc * (*)(); 
	PF f = (PF)ec_get_function_address(addr, "CreateProxy");

	//==============================
	ICalc* pCalc = f(); // DLL 안에서 "new Calc" 하고 있습니다.
						// 언젠가는 delete 해야 되지 않을까요 ?


	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ",  " << n2 << std::endl;

//	delete pCalc; // 안전한가요 ?? 좋은 코드 일까요 ?
				// 동적 모듈에서 자원 할당 한 경우 자원 해지도
				// 동적 모듈에서 하는 것이 안전합니다.
}







