﻿#include <iostream>
#include <vector>

class Car
{
	int mColor;

	int refCount = 0; // 참조계수 관리를 위한 멤버 변수
public:

	void AddRef() { ++refCount; }

	void Release()
	{
		if (--refCount == 0)
			delete this;
	}
	// protected 소멸자
	// 1. 외부에서 직접 delete 할수 없고
	// 2. 스택에 객체를 만들수 없다.
protected:
	~Car() { std::cout << "Car 파괴" << std::endl; }
};

int main()
{
	Car* p1 = new Car;
	p1->AddRef();   

	Car* p2 = p1;
	p2->AddRef();	

	// 참조 계수로 관리할 경우
	// 1. 절대 직접 delete 하면 안됩니다.
//	delete p1;

	// 2. 스택에 객체를 만들지 말고 힙에 만들어야 합니다.
//	Car c;

	p2->Release();	
	std::cout << "-------------" << std::endl;
	p1->Release();	
}






