﻿// DAY5.zip => DAY5 폴더 SERVER 폴더

#include <iostream>

class Point
{
public:
	int x, y;

	Point(int a, int b) : x(a), y(b) {}

	void set(int a, int b) { x = a; y = b; }

	// 상수 멤버 함수 : 멤버함수 뒤쪽에 const를 붙이는 문법
	// => 컴파일러에게 이함수는 멤버의 값을 변경하지 않을 것이라고 알려 주는 것.
	// => 상수 객체라도 이함수를 호출하게 해달라.
	void print() const
	{
//		x = 10; // error. 상수 멤버 함수 안에서는 모든 멤버를 상수 취급 한다.
		std::cout << x << ", " << y << std::endl; // ok
	}
};  
int main()
{
	const Point pt(1, 2); // 핵심 : pt는 상수객체 입니다

	// 아래 3줄 생각해 보세요.
	pt.x = 10;		// error. x는 public 에 있지만, 상수 이므로	
	pt.set(10, 20); // error.
	pt.print();		// error. 
					// 단, 상수 멤버 함수라면 에러가 아니다.

	// 핵심 : 상수 객체는 상수 멤버 함수만 호출할수 있다.					
}    
// github.com/codenuri/samsung  에서 오후 폴더에 올리겠습니다.
