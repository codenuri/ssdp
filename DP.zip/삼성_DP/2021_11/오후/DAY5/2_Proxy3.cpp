﻿#define USING_GUI
#include "cppmaster.h"

// 사용자        proxy      stub     server
// Add(10,20) => "1"  ===> "1" ===> Add(10, 20)

// RPC( Remote Procedure Call )
// 다른 프로세스의 함수를 호출하는 개념
// java, RMI ( Remote Method Invocation )

// 서버와 Proxy 가 동일한 기능을 제공함을 약속하기위해
// 인터페이스 도입
struct ICalc
{
	virtual int Add(int a, int b) = 0;
	virtual int Sub(int a, int b) = 0;

	virtual ~ICalc() {}
};

class Calc : public ICalc
{
	int server;
public:
	Calc() { server = ec_find_server("Calc"); }

	int Add(int a, int b) { return ec_send_server(server, 1, a, b); }
	int Sub(int a, int b) { return ec_send_server(server, 2, a, b); }
};

int main()
{
	Calc* pCalc = new Calc;
	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ",  " << n2 << std::endl;
}







