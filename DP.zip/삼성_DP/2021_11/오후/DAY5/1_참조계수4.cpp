﻿#include <iostream>
#include <vector>

class Car
{
	int mColor;

	mutable int refCount = 0; // mutable 멤버 데이타
						// 상수 멤버 함수 안에서도 변경가능한 멤버 데이타
public:
	// 핵심 : 참조계수를 관리하는 함수는 "상수 멤버함수"가 되어야 합니다
	void AddRef() const { ++refCount; }

	void Release() const
	{
		if (--refCount == 0)
			delete this;
	}
protected:
	~Car() { std::cout << "Car 파괴" << std::endl; }
};

int main()
{
	const Car* p1 = new Car;

	// 상수 객체라 하더라도.. 수명은 관리할수 있어야 합니다.
	p1->AddRef();
	p1->Release();
}






