﻿#include <iostream>
#include <vector>

class Car 
{
	int mColor;

	int refCount = 0; // 참조계수 관리를 위한 멤버 변수
public:

	void AddRef() { ++refCount; }

	void Release()
	{
		if (--refCount == 0)
			delete this;
	}
	~Car() { std::cout << "Car 파괴" << std::endl; }
};

int main()
{
	Car* p1 = new Car;
	p1->AddRef();     // 규칙 1. 객체를 생성하면 참조 계수 증가

	Car* p2 = p1;
	p2->AddRef();		// 규칙 2. 객체 주소를 복사하면 참조 계수 증가

	p2->Release();		// 규칙 3. 포인터 사용후에 참조계수 감소
	std::cout << "-------------" << std::endl;
	p1->Release();	// 이순간 참조계수가 0 이 되므로 객체 파괴	 
}






