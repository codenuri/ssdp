﻿#include <iostream>

struct BM	// Base Member라는 의미
{
	BM()  { std::cout << "BM()" << std::endl; }
	~BM() { std::cout << "~BM()" << std::endl; }
};
struct DM	// Derived Member 라는 의미
{
	DM()  { std::cout << "DM()" << std::endl; }
	~DM() { std::cout << "~DM()" << std::endl; }
};

struct Base
{
	BM bm;
	Base()  
	{
		std::cout << "Base()" << std::endl; 
	}
	~Base() { std::cout << "~Base()" << std::endl; }
};

/*
struct Derived : public Base
{
	DM dm;
	Derived()  
	{
		std::cout << "Derived()" << std::endl; 
	}
	~Derived() { std::cout << "~Derived()" << std::endl; }
};
*/
// 사용자가 위처럼 만들면 컴파일러가 아래 처럼 변경합니다
struct Derived : public Base
{
	DM dm;
	// 핵심 : 
	// 1. 기반 클래스 생성자가 먼저 호출되고, 
	// 2. 멤버의 생성자가 호출.
	// 3. Derived 생성자의 {} 안이 실행.

	Derived() : Base(), dm()
	{
		std::cout << "Derived()" << std::endl;
	}
	~Derived() { std::cout << "~Derived()" << std::endl; }
};

int main()
{
	Derived d;
}
