#include <iostream>
#include <functional>

struct identity
{
	template<typename T>
	T& operator()(T& obj) const { return obj; }
};

template<typename T, typename Proj = identity, typename Comp = std::less<void> >
const T& Max(const T& a, const T& b, Comp comp = {}, Proj f = {})
{
	return std::invoke(comp, std::invoke(f, a), std::invoke(f, b)) ? b : a;
}
struct Point
{
	int x = 0;
	int y = 0;
};
int main()
{
	Point p1, p2;
	Point p3 = Max(p1, p2, {}, &Point::y);
}