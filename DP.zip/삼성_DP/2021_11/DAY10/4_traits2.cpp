﻿#include <iostream>
#include <list>
#include <vector>

template<typename T> 
typename T::value_type sum(T first, T last)
{
	// T             : 반복자(iterator)
	// T::value_type : 반복자가 가리키는 요소의 타입
	typename T::value_type s{};

	while (first != last)
	{
		s = s + *first;
		++first;
	}
	return s;
}

int main()
{
	std::vector<int> c = { 1,2,3,4,5 };

	int n = sum( c.begin(), c.end() ); // 만들어 봅시다.
	
	std::cout << n << std::endl; // 15
}
