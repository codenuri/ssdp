﻿#include <iostream>
#include <thread>
#include <mutex>

// RAII ( Resource Acquision Is (자원관리객체가) Initialization )
// 자원을 획득하는 것은 (자원관리 객체가) 초기화될 때이다.
template<typename T> class lock_guard
{
	T& mtx;
public:
	lock_guard(T& m) : mtx(m) { mtx.lock(); }
	~lock_guard()             { mtx.unlock(); }
};

std::mutex m;

void foo()
{
	lock_guard<std::mutex> g(m);
//	m.lock();
	// 직접 lock/unlock 하면 이 부분에서 예외 발생시... deadlock 의 가능성이 있다.
//	m.unlock();
}

void goo()
{
	if (m.try_lock())
	{
		// lock 이 이미 했는데.. unlock 만 자동으로 하고 싶다.
		// m.unlock();
		// 그런데, 아래 처럼하면, 자동 unlock 되지만 
		lock_guard<std::mutex> g(m); // 생성자에서 lock 을 또 하게 된다.
	}
}


int main()
{
	std::thread t(foo);
	t.join();
}










