﻿#include <iostream>

// Base-from-Member

class Buffer
{
	char* buff;
public:
	Buffer(int size) : buff(new char[size]) 
	{
		std::cout << "버퍼 크기 " << size  << "로 초기화" << std::endl;
	}
	void useBuffer() { std::cout << "버퍼 사용" << std::endl; }
};

class Stream
{
public:
	Stream(Buffer& buf) { buf.useBuffer();	}
};
//==============================
// Stream 파생 클래스를 설계해 봅시다.
class MyStream : public Stream
{
	Buffer buff{ 1024 };  // 여기서 초기화 하고 있지만..
						// 정확한 원리는 컴파일러가 
						// MyStream() : Stream(buff), buff(1024) {} 처럼 변경한 것입니다.
public:
	MyStream() : Stream( buff ) {}
};

int main()
{
//	Buffer buff(1024);
//	Stream stream(buff);

	MyStream ms;
}


