﻿// empty1.cpp
#include <iostream>
#include <thread>
#include <mutex>

std::mutex m;

void foo()
{
//	m.lock();     // lock 을 획득하지 못하면 대기
	
	if (m.try_lock()) // lock 을 획득하지 못하면 false 반환
	{
		//....

		m.unlock();
	}
}

int main()
{
	std::thread t(foo);
	t.join();
}
