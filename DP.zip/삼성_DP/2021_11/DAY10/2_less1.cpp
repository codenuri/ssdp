﻿#include <iostream>
#include <string>

// less 만들기
// 1. 템플릿으로 ..
// 2. () 연산자는 상수 멤버함수로 만들고
// 3. constexpr inline 등을 붙이는 것이 성능향상에 도움이 된다.
template<typename T> struct less
{
	constexpr inline bool operator()(const T& a, const T& b) const 
	{
		return a < b;
	}
};

template<typename T> void foo(const T& f)
{
	bool b = f(10, 20); // f.operator()(10,20) 는데.. f가 상수객체입니다.
}

int main()
{
	less<int> fi; // int 2개를 비교
	bool b1 = fi(10, 20); // 10 < 20

	foo(fi);

	std::string s1 = "A";
	std::string s2 = "B";

	less<std::string> fs;
	bool b2 = fs(s1, s2);
}
