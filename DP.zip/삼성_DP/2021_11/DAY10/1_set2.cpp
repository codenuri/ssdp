﻿#include <iostream>
#include <set>
#include <string>

struct People
{
	std::string name;
	int age;

	People(std::string name, int age) : name(name), age(age) {}
};

struct PeopleCompare
{
	inline bool operator()(const People& p1, const People& p2) const
	{
		return p1.age < p2.age;
	}
};


int main()
{
	// 1. std::set 에 사용자 정의 타입 넣기.
	// => People 2개를 비교할수 있는 함수객체를 전달해야 한다.
	std::set<People, PeopleCompare> s;

	s.insert(People("kim", 20));
	s.insert(People("lee", 10));
	s.insert(People("park", 24));
	s.insert(People("choi", 30));



}
