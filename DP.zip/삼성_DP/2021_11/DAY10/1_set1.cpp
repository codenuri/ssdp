﻿#include <iostream>
#include <set> // 대부분 RB Tree 로 구현 합니다.
#include <functional>

/*
// set 의 실제 구현 원리
template<typename T, // 저장 요소의 타입
	     typename Pr = std::less<T>, // 요소 비교에 사용할 객체
	     typename Alloc = std::allocator<T>> // 메모리 할당기
class set
{
	Pr pr;
public:
	void insert(const T& element)
	{
//		if ( root->elem < element ) // 이렇게 < 를 직접 사용하지 않고
		if (pr(root->elem, element))
			add right child;

		else if (pr(element, root->elem))
			add left child;

		else
			return fail; 

	}
};
*/
// github.com/codenuri/samsung 에서 받을수 있습니다

int main()
{
//	std::set<int> s; // 요소 비교시 std::less 사용
	 
	std::set<int, std::greater<int> > s; // std::greater 로 비교 해달라.

	s.insert(20);
	s.insert(10);
	s.insert(30);
	s.insert(15);
	s.insert(25);

	for (auto e : s)
		std::cout << e << ", ";

	std::cout << std::endl;
}
