﻿#include <iostream>
#include <list>
#include <vector>

/*
void print_first_element(std::vector<int>& v)
{
	int n = v.front();

	std::cout << n << std::endl;
}
*/

/*
template<typename T> 
void print_first_element(std::vector<T>& v)
{
	T n = v.front();

	std::cout << n << std::endl;
}
*/

template<typename T>
void print_first_element(T& v)
{
	// T : list<double> 입니다.
	// T::value_type => list<double>::value_type => double
	// 우리가 원하는 것은 "double" 입니다.

	// T::이름          : "이름"을 static 멤버 데이타로 생각
	// typename T::이름 : "이름"을 타입의 이름으로 생각해달라는 것.

	typename T::value_type n = v.front();

	auto n2 = v.front(); // 이렇게 해도 되지만, auto 를 표기하기 어려운 경우도 있습니다.

	std::cout << n << std::endl;
}
int main()
{
//	std::vector<int>    c = { 1,2,3,4,5 };
//	std::vector<double> c = { 1,2,3,4,5 };
	std::list<double> c = { 1,2,3,4,5 };

	print_first_element(c);
}

// 템플릿 기반의 컨테이너는 자신이 저장하는 타입이 있습니다.
// 그런데, 컨테이너가 저장하는 타입을 외부에서 알고 싶을때가 있습니다.
// 그래서 STL 설계시 아래처럼 만들었습니다.
/*
template<typename T> class list
{
public:
//	typedef T value_type; // C++98 스타일

	using value_type = T; // C++11이후 스타일
};

list<int> s = { 1,2,3 };
list<int>::value_type n = s.front();
*/

