﻿// 2_컨테이너 - 99 page
#include <iostream>

struct Node
{
	int  data;
	Node* next;
	Node(int d, Node* n) : data(d), next(n) {}
};

class slist
{
	Node* head = nullptr;
public:
	// 생성자를 잘 활용하면 한줄로 slist 의 앞에 넣을수 있습니다.
	void push_front(int a) { head = new Node(a, head); }
	
	int front() { return head->data; }
};

int main()
{
	slist s;
	s.push_front(10);
	s.push_front(20);
	s.push_front(30);
	s.push_front(40); // 이순간의 메모리 그림을 생각해보세요
}




