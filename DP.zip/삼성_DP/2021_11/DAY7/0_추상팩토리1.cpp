﻿// 3_추상팩토리 - 147
#include <iostream>

struct WinButton 
{
	void Draw() { std::cout << "Draw WinButton" << std::endl; }
};
struct WinEdit 
{
	void Draw() { std::cout << "Draw WinEdit" << std::endl; }
};

struct OSXButton 
{
	void Draw() { std::cout << "Draw OSXButton" << std::endl; }
};
struct OSXEdit 
{
	void Draw() { std::cout << "Draw OSXButton" << std::endl; }
};

int main(int argc, char** argv)
{
	? btn;
	if (strcmp(argv[0], "-style:OSX") == 0)
		btn = new OSXButton;
	else
		btn = new WinButton;
}








