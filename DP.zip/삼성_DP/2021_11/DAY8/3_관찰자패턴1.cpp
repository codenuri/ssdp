﻿// 3_관찰자패턴1 - 94 page
#include <iostream>
#include <vector>


struct IGraph
{
	virtual void Update(int data) = 0;
	virtual ~IGraph() {}
};

class Table
{
	std::vector<IGraph*> v;
	int value; // table 의 data 값
public:
	void attach(IGraph* p) { v.push_back(p); }
	void detach(IGraph* p) {}
	void notify(int data)
	{
		for (auto p : v)
			p->Update(data);
	}
	void edit()
	{
		while (1)
		{
			std::cout << "Data >>";
			std::cin >> value;

			notify(value); 
		}
	}
};
//----------------------
class BarGraph : public IGraph
{
public:
	void Update(int n) override
	{
		std::cout << "Bar Graph : ";

		for (int i = 0; i < n; i++)
			std::cout << "*";

		std::cout << std::endl;
	}
};

int main()
{
	Table t;

	BarGraph bg; 
	t.attach(&bg);

	t.edit();
}


