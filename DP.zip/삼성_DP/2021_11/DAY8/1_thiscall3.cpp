﻿#define USING_GUI
#include "cppmaster_gui.h"
#include <iostream>

int foo(int hwnd, int msg, int a, int b)
{
	switch (msg)
	{
	case WM_LBUTTONDOWN: std::cout << "LBUTTON" << hwnd << std::endl; break;
	case WM_KEYDOWN:     std::cout << "KEYDOWN" << hwnd << std::endl; break;
	}
	return 0;
}

int main()
{
	int h1 = ec_make_window(foo, "A");
	int h2 = ec_make_window(foo, "B");

	ec_process_message();
}

/*

// 아래 클래스가 라이브러리 내부 클래스 입니다.
class CWnd
{
public:
	void Create()
	{
	
	}
	virtual void LButtonDown() {}
	virtual void KeyDown() {}
};


class MyWindow : public CWnd
{
public:
	void LButtonDown() { cout << "LBUTTON" << endl; }
};

int main()
{
	// 사용법
	MyWindow w;
	w.Create(); // 이순간 윈도우가 생성되고
				// 마우스를 누르면 가상함수 LButtonDown()이 호출되야합니다.

	ec_process_message();
}
*/
