﻿#include <iostream>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <algorithm>

int main()
{
	std::list<int> ss = { 1,2,3,4,5 };

	auto p = ss.begin();
	++p;
	std::cout << *p << std::endl;
	
	auto ret = std::find(ss.begin(), ss.end(), 3);

	std::cout << *ret << std::endl;
}


template<typename IT, typename T>
IT find(IT first, IT last, T value)
{
	while (first != last && *first != value)
		++first;

	return first;
}