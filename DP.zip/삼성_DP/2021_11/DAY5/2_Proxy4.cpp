﻿#define USING_GUI
#include "cppmaster.h"

// ICalc.h 파일 만드세요.
struct ICalc
{
	virtual int Add(int a, int b) = 0;
	virtual int Sub(int a, int b) = 0;

	virtual ~ICalc() {}
};

class Calc : public ICalc
{
	int server;
public:
	Calc() { server = ec_find_server("Calc"); }

	int Add(int a, int b) { return ec_send_server(server, 1, a, b); }
	int Sub(int a, int b) { return ec_send_server(server, 2, a, b); }
};

// 위에 있는 Proxy 클래스는 누가 만들게 될까요 ?
// 1. 서버제작자 ===> 정답
// 2. 클라이언트 제작자

int main()
{
	// 클라이언트 제작자가 아래 처럼 Proxy(Calc)를 사용하면
	// 강한 결합(tightly coupling) 입니다.
	// 새로운 Proxy 가 등장하면 아래 코드는 수정되어야 합니다.
	// OCP를 만족할수 없습니다.
	// Calc* pCalc = new Calc;

	// 약한 결합, 즉, 인터페이스를 사용해서
	// 통신해야 합니다.
	// 그런데 ?? 는 어떻게 해야 할까요 ??
	ICalc* pCalc = new ??;


	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ", " << std::endl;
}







