﻿#include <iostream>
#include <vector>

class Car 
{
	int mColor;

	int refCount = 0; // 참조 계수 관리를 위한 변수
public:
	void AddRef() { ++refCount; }

	void Release()
	{
		if (--refCount == 0)
			delete this;
	}
	~Car() { std::cout << "Car 파괴" << std::endl; }
};
int main()
{ 
	Car* p1 = new Car;
	p1->AddRef(); // 규칙 1. 객체 생성시 참조 계수 증가

	Car* p2 = p1;
	p2->AddRef(); // 규칙 2. 포인터 복사시 참조 계수 증가

	p2->Release(); // 규칙 3. 포인터 사용후에는 참조 계수 감소
	std::cout << "-----------------" << std::endl;
	p1->Release(); // 참조 계수 0 되므로 객체 파괴
}
// github.com/codenuri/samsung





