﻿// DAY5.zip => "DAY5" 폴더, "SERVER"

#include <iostream>

class Point
{
public:
	int x, y;

	Point(int a, int b) : x(a), y(b) {}

	void set(int a, int b) { x = a; y = b; }

	// 상수 멤버 함수 ( const member function )
	void print() const
	{
//		x = 10; // error. 상수 멤버 함수 안에서 모든 멤버는 상수 취급된다.
		std::cout << x << ", " << y << std::endl;
	}
}; 
int main()
{
	const Point pt(1, 2); // 상수 객체.. 

	// 이제 아래 코드를 생각해보세요
	pt.x = 10;	    // error. x가 public 이지만 상수이므로	
	pt.set(10, 20); // error.
	pt.print();		// error. 	
					// 단, 상수 멤버 함수로 만들면 호출 가능하다.

	// 핵심 : 상수 객체는 상수 멤버 함수만 호출가능하다.				
}   
// github.com/codenuri/samsung  에 소스 올리겠습니다.

