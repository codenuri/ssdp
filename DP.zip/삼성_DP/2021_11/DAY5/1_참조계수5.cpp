﻿#include <iostream>
#include <vector>

class RefCount
{
	mutable int refCount = 0; // mutable 멤버 데이타
							  // => 상수 멤버 함수 안에서도 값을 변경할수 있게 
							  //    하는 멤버 데이타 만들때 사용
public:
	// 핵심 : 참조계수를 다루는 함수는 상수 멤버 함수가 되어야 합니다.
	void AddRef() const { ++refCount; }

	void Release() const // void Release(RefCount* this)
	{
		if (--refCount == 0)
			delete this;
	}
protected:
	virtual ~RefCount() {  }
};

class Truck : public RefCount
{
	int color;
	int speed;
public:
	~Truck() { std::cout << "Truck 파괴" << std::endl; }
};
int main()
{
	const Truck* p = new Truck;

	p->AddRef();
	p->Release();
}


// github.com/codenuri/samsung





