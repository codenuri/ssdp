﻿// visual studio 추가로 한개 더 실행해서 SERVER 프로젝트 열어 보세요.

#define USING_GUI
#include "cppmaster.h"

int main()
{
	// 1. 서버의 핸들을 얻어 옵니다.
	int server = ec_find_server("Calc");

	cout << "서버 번호 : " << server << endl;


	// 2. 서버에 명령코드와 파라미터를 전달합니다.
	int n1 = ec_send_server(server, 1, 10, 20);
	int n2 = ec_send_server(server, 2, 10, 20);

	cout << n1 << ", " << n2 << endl;

}







