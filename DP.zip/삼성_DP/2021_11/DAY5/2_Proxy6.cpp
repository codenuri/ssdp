﻿#define USING_GUI
#include "cppmaster.h"
#include "ICalc.h"

int main()
{
	void* addr = ec_load_module("CalcProxy.dll");
	using PF = ICalc * (*)(); 
	PF f = (PF)ec_get_function_address(addr, "CreateProxy");

	//===========
	ICalc* pCalc = f(); // 동적모듈(dll) 에서 "new Calc" 하고 있습니다

	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ", " << n2 << std::endl;

//	delete pCalc; // ?? 될까요 ? 안전 한가요 ?
				// 동적 모듈을 만들때 컴파일러와 
				// client 만들때 컴파일러가 다를수 있습니다.
				// 동적모듈이 할당한 자원은 동적 모듈이 해지 해야 안전합니다.
	
}







