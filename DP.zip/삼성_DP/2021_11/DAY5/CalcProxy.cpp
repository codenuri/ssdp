#define USING_GUI
#include <iostream>
#include <atomic>
#include "cppmaster.h"
#include "ICalc.h"

class Calc : public ICalc
{
	int server;
	mutable std::atomic<int> refCount{ 0 };
public:
	void AddRef() const { ++refCount;}

	void Release() const
	{
		if (--refCount == 0)
			delete this;
	}

	Calc() { server = ec_find_server("Calc"); }

	int Add(int a, int b) { return ec_send_server(server, 1, a, b); }
	int Sub(int a, int b) { return ec_send_server(server, 2, a, b); }

	~Calc() { std::cout << "~Calc" << std::endl; }
};

extern "C" __declspec(dllexport)
ICalc* CreateProxy()
{
	return new Calc;
}




