﻿#define USING_GUI
#include "cppmaster.h"

// 서버를 대신하는 클래스를 도입해 봅시다.
// proxy 패턴 : 대행자(대신하는 클래스)를 만드는 패턴
// remote proxy : 원격지 서버를 대신하는 클래스

// 장점 1. Client 제작자는 IPC 코드를 알필요 없다. Proxy 클래스 사용법만 알면 된다.
//     2. 자주 사용하는 연산의 결과등은 "캐쉬"로 관리 할수도 있다.
//        그외.. 여러가지 장점이 있다.

// Proxy : 함수 호출을 명령 코드로 변경해서 서버에 전달(Add() => "1" 을 서버에 전달)
// Stub  : 도착 한 명령 코드를 다시 함수 호출로 변경( "1" => Server.Add() 호출)
//		   SERVER 프로젝트에 있는 dispatch 함수가 stub 입니다.

class Calc
{
	int server;
public:
	Calc() { server = ec_find_server("Calc"); }

	int Add(int a, int b) { return ec_send_server(server, 1, a, b); }
	int Sub(int a, int b) { return ec_send_server(server, 2, a, b); }
};
int main()
{
	// 이제 서버에 접속해서 서비스를 받으려면
	// Proxy 객체를 생성해서 멤버 함수만 호출하면 됩니다.
	Calc* pCalc = new Calc;
	
	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ", " << std::endl;
}







