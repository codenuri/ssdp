﻿// 6_Bridge1 - 90 page
#include <iostream>

// 모든 MP3 제품은 아래 인터페이스를 구현해야 한다.
struct IMP3
{
	virtual void Play() = 0;
	virtual void Stop() = 0;
	virtual ~IMP3() {}
};

class IPod : public IMP3
{
public:
	void Play() { std::cout << "Play MP3 with IPod" << std::endl; }
	void Stop() { std::cout << "Stop" << std::endl; }
};

class People
{
public:
//	void Use(IPod* p) // IPod 만 사용가능
	void Use(IMP3* p) // 다양한 MP3 제품으로 교체 가능
	{
		p->Play();
		p->Stop();

		// 나중에 요구조건이 생겼다..
		// 1분 미리 듣기 하고 싶다.
		p->PlayOneMinute(); // 제공하려면, 인터페이스가 수정되어야 한다.
							// 인터페이스를 변경하는 것은 너무나 힘든 작업입니다.
							// "인터페이스 불변의 법칙"
	}
};

int main()
{
	People p;
	IPod pod;
	p.Use(&pod);
}


