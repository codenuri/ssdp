﻿#include <iostream>
#include <vector>

class RefCount
{
	mutable int refCount = 0;
public:
	void AddRef() const { ++refCount; }

	void Release() const 
	{
		if (--refCount == 0)
			delete this;
	}
protected:
	virtual ~RefCount() {  }
};

class Truck : public RefCount
{
	int color;
	int speed;
public:
	~Truck() { std::cout << "Truck 파괴" << std::endl; }

	void Go() { std::cout << "Truck Go" << std::endl; }
};

// 객체의 참조 계수 함수(AddRef, Release) 를 자동으로 호출해 주는
// 스마트 포인터를 만들어 봅시다.
template<typename T> class AutoPtr
{
	T* obj;
public:
	AutoPtr(T* p = nullptr)    : obj(p)      { if (obj) obj->AddRef(); }
	AutoPtr(const AutoPtr& ap) : obj(ap.obj) { if (obj) obj->AddRef(); }
	~AutoPtr() { if (obj) obj->Release(); }

	// 스마트포인터의 기본 : ->, * 연산자를 재정의 해서 포인터 처럼 보이도록!
	T* operator->() { return obj; }
	T& operator*() { return *obj; }
};

int main()
{
	AutoPtr<Truck> p1 = new Truck; // AutoPtr<Truck> p1(new Truck);
	AutoPtr<Truck> p2 = p1;

	p1->Go();
	(*p1).Go();

//	Truck* p1 = new Truck;
//	p1->AddRef();
//	Truck* p2 = p1;
//	p2->AddRef();

//	p2->Release();
//	p1->Release();
}







