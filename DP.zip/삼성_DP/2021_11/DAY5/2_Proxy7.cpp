﻿#define USING_GUI
#include "cppmaster.h"
#include "ICalc.h"

int main()
{
	void* addr = ec_load_module("CalcProxy.dll");
	using PF = ICalc * (*)();
	PF f = (PF)ec_get_function_address(addr, "CreateProxy");

	//===========
	ICalc* pCalc = f(); 

	pCalc->AddRef(); // 이렇게 사용하려면 ICalc 안에 AddRef 함수가 
					 // 있어야 합니다.

	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ", " << n2 << std::endl;

	pCalc->Release();
}







