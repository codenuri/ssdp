﻿#include <iostream>
#include <vector>

class Car
{
	int mColor;

	int refCount = 0; 
public:
	void AddRef() { ++refCount; }

	void Release()
	{
		if (--refCount == 0)
			delete this;
	}
	// protected 소멸자 
	// 1. 외부에서 delete 할수 없게 하고
	// 2. 스택에 객체를 만들수 없다.
protected:
	~Car() { std::cout << "Car 파괴" << std::endl; }
};
int main()
{
	Car* p1 = new Car;
	p1->AddRef(); 

	// 주의
	// 1. 절대 직접 delete 하면 안된다.
//	delete p1;
	// 2. 스택 객체를 만들지 말고 힙객체로 사용
//	Car c;

	p1->Release();
}


// github.com/codenuri/samsung





