﻿#include <iostream>
#include <vector>

// 참조계수 기능을 제공하기 위한 기반 클래스
class RefCount
{
	int refCount = 0;
public:
	void AddRef() { ++refCount; }

	void Release()		// void Release(RefCount* this)
	{
		if (--refCount == 0)
			delete this; // 여기서 this 타입은 "RefCount*" 입니다.
						// this가 기반 클래스 포인터 이므로..
						// Truck 소멸자가 정상적으로 호출되려면
						// RefCount 의 소멸자는 반드시 가상함수 이어야 합니다
						 
	}
protected:
	virtual ~RefCount() {  }
};

class Truck : public RefCount
{
public:
	~Truck() { std::cout << "Truck 파괴" << std::endl; }
};
int main()
{
	// Truck 도 참조 계수로 관리 하고 싶다.
	Truck* p = new Truck;

	p->AddRef();
	p->Release();
}


// github.com/codenuri/samsung





