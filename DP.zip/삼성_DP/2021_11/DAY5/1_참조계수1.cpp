﻿#include <iostream>
#include <vector>
using namespace std;

class Car {};

vector<Car*> v;

void foo()
{
	Car* p = new Car;

	v.push_back(p);

	// 여기서는 더이상 p가 필요없습니다.
	delete p; // 이렇게 해도 될까요 ?
}

int main()
{
	foo();
}

