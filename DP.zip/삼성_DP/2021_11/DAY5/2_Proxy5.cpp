﻿#define USING_GUI
#include "cppmaster.h"

// Client 제작자는 서버 제작자에게 2개의 파일을 받아야 합니다.

// ICalc.h       : 인터페이스가 들어 있는 헤더 파일
// CalcProxy.dll : Proxy 가 있는 동적 모듈

#include "ICalc.h"

int main()
{
	// 1. 동적 모듈 Load
	void* addr = ec_load_module("CalcProxy.dll");
				// linux : dl_open(),  window : LoadLibrary()

	// 2. 동적 모듈에 있는 약속된 함수 찾기
	using PF = ICalc* (*)();  // typedef ICalc*(*PF)()

	PF f = (PF)ec_get_function_address(addr, "CreateProxy");
				// linux : dl_sym(),   windows : GetProcAddress()

	// 3. 약속된 함수로 Proxy 객체 생성
	ICalc* pCalc = f(); // 동적 모듈 내의 약속된 함수를 통해서 Proxy 생성


	int n1 = pCalc->Add(10, 20);
	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ", " << n2 << std::endl;
}
// 이제 위 코드에는 "Proxy Class" 이름은 없습니다.
// 새로운 Proxy 가 나와도 코드 수정이 되지 않습니다.
// 단, 새로운 Proxy 가 나오면
// 1. DLL 의 이름(CalcProxy.dll) 은 유지해야 하고
// 2. DLL 안에 반드시 "CreateProxy" 함수가 있어야 합니다.






