﻿#define USING_GUI
#include "cppmaster.h"

// RPC ( Remote Procedure Call ) : 다른 프로세스에 있는 함수를 호출하는 것
// Java 는 "RMI ( Remove Method Invocation )"

// 서버와 Proxy 가 동일한 함수 이름을 사용하는 것을 보장하기 위해
// 인터페이스 도입
// 규칙  : 서버와 Proxy 는 모두 아래 인터페이스를 구현해야 한다.
struct ICalc
{
	virtual int Add(int a, int b) = 0;
	virtual int Sub(int a, int b) = 0;

	virtual ~ICalc() {}
};

// 서버에 새로운 기능이 추가되려면
// 인터페이스, 서버, Proxy 클래스, Stub(dispatch) 코드 가 수정되어야 합니다.
// IDL(Inteface Definition Language) 를 사용하면 
// 서버 기능 추가시 관련된 코드를 proxy, stub 에 자동으로 추가하는 기능을 지원 받을수 있습니다.


class Calc : public ICalc
{
	int server;
public:
	Calc() { server = ec_find_server("Calc"); }

	int Add(int a, int b) { return ec_send_server(server, 1, a, b); }
	int Sub(int a, int b) { return ec_send_server(server, 2, a, b); }
};
int main()
{
	Calc* pCalc = new Calc;

	int n1 = pCalc->Add(10, 20); // Add() => "1" 을 서버에 전달
								 // 서버 : "1" 도착 => Server.Add() 호출

	int n2 = pCalc->Sub(10, 20);

	std::cout << n1 << ", " << std::endl;
}







