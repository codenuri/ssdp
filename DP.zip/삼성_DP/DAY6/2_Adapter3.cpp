#include <iostream>
#include <list>
#include <vector>
#include <deque>
using namespace std;

// STL �� adapter..
template<typename T, typename C = deque<T>> 
class stack
{
	C c;
public:
	void push(const T& a) { c.push_back(a); }
	void pop()            { c.pop_back(); }
};
int main()
{
	stack<int> s;
	s.push(10);
}