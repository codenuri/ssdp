﻿#include <iostream>
#include <vector>
#include <stack>
#include <queue>
#include <list>
using namespace std;

// STL 은 어답터 패턴을 많이 사용합니다.
// 반복자 어답터
int main()
{
	list<int> ss = { 1,2,3,4,5 };

	auto p = ss.begin();

	++p;
	cout << *p << endl;

}
