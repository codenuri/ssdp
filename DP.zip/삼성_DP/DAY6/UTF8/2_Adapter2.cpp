﻿// 1_Adapter1.cpp - 1일차소스에서 도형편집기1 복사해오세요
// 73page
#include <iostream>
#include <vector>
using namespace std;

// 아래 클래스가 이미 있었다가 가정해 봅시다.
#include <string>

class TextView
{
	string data;
public:
	TextView(string s) : data(s) {}

	void Show() { cout << data << endl; }
};






class Shape
{
public:
	virtual void Draw() = 0;// { cout << "Draw Shape" << endl; }
	virtual ~Shape() {}
};


class Rect : public Shape
{
public:
	void Draw() override { cout << "Draw Rect" << endl; }
};
class Circle : public Shape
{
public:
	void Draw() override { cout << "Draw Circle" << endl; }
};


// 클래스 어답터 : 다중 상속의 모양
// 객체 어답터 : 포함(값이 아닌 포인터또는 참조) + 상속의 구조

class Text : public Shape
{
	TextView* tv;
public:
	Text(TextView* p) : tv(p) {}

	void Draw() override{	tv->Show();	}
};

int main()
{
	vector<Shape*> v;

	TextView tv("ABCD");
	//v.push_back(&tv); // error
	v.push_back(new Text(&tv)); // ok..
						// 객체에 어답터를 끼워서 사용

	v[0]->Draw();
}







