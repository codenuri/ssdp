﻿// 3_도형편집기 - 15 page
#include <iostream>
#include <vector>
using namespace std;

int main()
{
}

