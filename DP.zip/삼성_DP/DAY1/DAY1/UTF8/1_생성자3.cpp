﻿// 생성자3

// 아래 코드를 컴파일 했을때 에러가 나오는 곳은 정확히 어디 일까요 ?
class Base
{
public:
	Base(int a) {}
};
class Derived : public Base
{
public:
	Derived()      : Base(0) {}
	Derived(int n) : Base(n) {}
};
int main()
{
	Derived d;
}






