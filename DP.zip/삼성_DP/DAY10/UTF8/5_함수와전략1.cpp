﻿#include <iostream>
#include <algorithm>

int* find(int* first, int* last, int v)
{
	while (first != last && *first != v)
		++first;

	return first;
}

int main()
{
	int x[10] = { 0,1,2,6,7,8,3,4,5,9 };

	int* p = find(x, x + 10, 3);

	std::cout << *p << std::endl;

	// "3" 이라는 값이 아니라 "처음 나오는 3의 배수"를 찾고 싶다.
	// => 값이 아닌 조건 검색
}
