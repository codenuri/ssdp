#include <iostream>
#include <vector>
#include <map>
#include "Helper.h"

class Shape
{
public:
	virtual void Draw() = 0;
	virtual ~Shape() {}
};

class ShapeFactory
{
	MAKE_SINGLETON(ShapeFactory)
		using CREATOR = Shape * (*)();

	std::map<int, CREATOR> create_map;
public:
	void Register(int key, CREATOR f)
	{
		create_map[key] = f;
	}
	Shape* Create(int type)
	{
		Shape* p = nullptr;

		if (create_map[type] != nullptr)
		{
			p = create_map[type]();
		}
		return p;
	}
};


class RegisterShape
{
public:
	RegisterShape(int type, Shape*(*f)())
	{
		ShapeFactory& factory = ShapeFactory::getInstance();

		factory.Register(type, f);
	}
};



#define DECLARE_SHAPE(classname )							\
	static Shape* Create() { return new classname; }		\
	static RegisterShape rs;

#define IMPLEMENT_SHAPE(key, classname)						\
	RegisterShape classname::rs(key, &classname::Create);


class Rect : public Shape
{
public:
	void Draw() override { std::cout << "Draw Rect" << std::endl; }

	// ��� : ��� �������� �Ʒ� 2���� ��ũ�θ� ������ �˴ϴ�.
	DECLARE_SHAPE(Rect)
};
IMPLEMENT_SHAPE(1, Rect)

class Circle : public Shape
{
public:
	void Draw() override { std::cout << "Draw Circle" << std::endl; }

	DECLARE_SHAPE(Circle)
};
IMPLEMENT_SHAPE(2, Circle)

class Triangle : public Shape
{
public:
	void Draw() override { std::cout << "Draw Triangle" << std::endl; }

	DECLARE_SHAPE(Triangle)
};
IMPLEMENT_SHAPE(3, Triangle)

int main()
{
	std::vector<Shape*> v;
	ShapeFactory& factory = ShapeFactory::getInstance();

	while (1)
	{
		int cmd;
		std::cin >> cmd;

		if (cmd >= 1 && cmd <= 7)
		{
			Shape* s = factory.Create(cmd);

			if (s != nullptr)
				v.push_back(s);
		}


		else if (cmd == 9)
		{
			for (int i = 0; i < v.size(); i++)
			{
				v[i]->Draw();
			}
		}
	}
}




