#include <iostream>
#include <vector>
using namespace std;

// IGraph.h ����� �Ʒ� �������̽� ��������
#include "IGraph.h"

#define USING_GUI
#include "cppmaster.h"

class Subject
{
	vector<IGraph*> v;
public:
	Subject()
	{
		// ��ӵ� ������ �ִ� ��� DLL�� �����մϴ�
		ec_enum_files("E:\\GRAPH", "*.dll", foo, this);		
	}

	static int foo(std::string name, void* p)
	{
		Subject* self = static_cast<Subject*>(p);

		std::cout << name << " ã��" << std::endl;

		void* addr = ec_load_module(name.c_str());
		
		typedef IGraph*(*F)();
		F f = (F)ec_get_function_address(addr, "CreateGraph");

		IGraph* g = f(); // Graph ��ü ����

		self->attach(g); // table �� �׷��� ����

		return 1; // ��� ã����� �ǹ�.
	}






	void attach(IGraph* p) { v.push_back(p); }
	void detach(IGraph* p) {}
	void notify(int data)
	{
		for (auto p : v)
			p->Update(data);
	}
};





class Table : public Subject
{
	int value;
public:
	void edit()
	{
		while (1)
		{
			cout << "Data >>";
			cin >> value;

			notify(value);
		}
	}
};
//----------------------
class BarGraph : public IGraph
{
public:
	void Update(int n) override
	{
		cout << "Bar Graph : ";

		for (int i = 0; i < n; i++)
			cout << "*";

		cout << endl;
	}
};

class PieGraph : public IGraph
{
public:
	void Update(int n) override
	{
		cout << "Pie Graph : ";

		for (int i = 0; i < n; i++)
			cout << ")";

		cout << endl;
	}
};

int main()
{
	Table t;
	BarGraph bg; t.attach(&bg);
	PieGraph pg; t.attach(&pg);
	t.edit();
}





