// 7_�̱���1 - 123 page
#include <iostream>
#include "helper.h"

class Cursor
{
	MAKE_SINGLETON(Cursor)
};


int main()
{
	Cursor& c1 = Cursor::getInstance();
	Cursor& c2 = Cursor::getInstance();

	std::cout << &c1 << std::endl;
	std::cout << &c2 << std::endl;
	
}








