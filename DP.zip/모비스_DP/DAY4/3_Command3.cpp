// 3_Command 
#include <iostream>
#include <vector>
#include <stack>



class Shape
{
public:
	virtual void Draw() = 0;
	virtual ~Shape() {}
};

class Rect : public Shape
{
public:
	void Draw() override { std::cout << "Draw Rect" << std::endl; }
};
class Circle : public Shape
{
public:
	void Draw() override { std::cout << "Draw Circle" << std::endl; }
};

struct ICommand
{
	virtual void Execute() = 0;
	virtual bool CanUndo() { return false; }
	virtual void Undo() {}
	virtual ~ICommand() {}
};


class AddCommand : public ICommand
{
	std::vector<Shape*>& v;
public:
	AddCommand(std::vector<Shape*>& v) : v(v) {}

	void Execute() override
	{
		v.push_back(CreateShape());
	}
	bool CanUndo() override { return true; }
	void Undo() override
	{
		Shape* p = v.back();
		v.pop_back();
		delete p;
	}
	virtual Shape* CreateShape() = 0;
};

class AddRectCommand : public AddCommand
{
public:
	using AddCommand::AddCommand;  
	virtual Shape* CreateShape() { return new Rect; }
};

class AddCircleCommand : public AddCommand
{
public:
	using AddCommand::AddCommand;
	virtual Shape* CreateShape() { return new Circle; }
};





class DrawCommand : public ICommand
{
	std::vector<Shape*>& v;
public:
	DrawCommand(std::vector<Shape*>& v) : v(v) {}

	void Execute() override
	{
		for (auto p : v)
			p->Draw();
	}
	bool CanUndo() override { return true; }
	void Undo() override
	{
		system("cls");
	}
};

// �������� ������ ��� �ϳ��� �������� ó���Ҽ� �ִ� ��ũ�� ����
// �ϳ��� ��ũ�� ������ �ٸ� ��ũ�� ���ɿ� ���Եɼ� �־�� �Ѵ�.
// ���հ�ü�� ������ü �� �ƴ϶� ���հ�ü �ڽŵ� �����Ҽ� �ִ�. => "Composite ����"
class MacroCommand :  public ICommand 
{
	std::vector<ICommand*> v;
public:
	void AddCommand(ICommand* p) { v.push_back(p); }
	void Execute()  {	for (auto p : v) p->Execute();	}
};

int main()
{
	std::vector<Shape*> v;

	MacroCommand* mc1 = new MacroCommand();
	mc1->AddCommand(new AddRectCommand(v));
	mc1->AddCommand(new AddCircleCommand(v));
	mc1->AddCommand(new DrawCommand(v));
	
//	mc1->Execute(); // ��ϵ� 3���� �۾��� ���ÿ� ����..

	MacroCommand* mc2 = new MacroCommand();
	mc2->AddCommand( new AddRectCommand(v) );
	mc2->AddCommand(mc1);
	mc2->Execute();




	std::stack<ICommand*> cmd_stack;
	ICommand* pCommand = nullptr;

	while (1)
	{
		int cmd;
		std::cin >> cmd;


		if (cmd == 1)
		{
			pCommand = new AddRectCommand(v);
			pCommand->Execute();
			cmd_stack.push(pCommand);
		}
		else if (cmd == 2)
		{
			pCommand = new AddCircleCommand(v);
			pCommand->Execute();
			cmd_stack.push(pCommand);
		}
		else if (cmd == 9)
		{
			pCommand = new DrawCommand(v);
			pCommand->Execute();
			cmd_stack.push(pCommand);
		}
		else if (cmd == 0)
		{
			if (!cmd_stack.empty())
			{
				pCommand = cmd_stack.top();
				cmd_stack.pop();

				if (pCommand->CanUndo())
				{
					pCommand->Undo();
				}
				delete pCommand;
			}

		}
	}
}


