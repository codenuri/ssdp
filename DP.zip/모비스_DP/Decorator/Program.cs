﻿using System;
using System.IO;
using System.IO.Compression;

namespace Decorator
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] arr = new byte[1024]; // 배열
            arr[0] = 65;
            arr[1] = 66;

            FileStream fs = new FileStream("a.txt", FileMode.CreateNew, FileAccess.Write);

            //    fs.Write(arr, 0, 1024);

            GZipStream gs = new GZipStream(fs, CompressionLevel.Fastest);

            gs.Write(arr, 0, 1024); // Decorator와 FileStream 은 사용법이 동일 합니다.

            gs.Dispose();
            fs.Dispose();
        }
    }
}












