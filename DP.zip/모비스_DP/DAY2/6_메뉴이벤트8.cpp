#include <iostream>
#include <string>
#include <vector>
#include <functional>
#include <memory>
using namespace std;
using namespace std::placeholders; // _1, _2, _3... 

class BaseMenu
{
	string title;
public:
	BaseMenu(string s) : title(s) {}

	string getTitle() const { return title; }

	virtual void command() = 0;
};



class PopupMenu : public BaseMenu
{
	vector< std::shared_ptr<BaseMenu> > v;
public:
	PopupMenu(string s) : BaseMenu(s) {}

	void addMenu( std::shared_ptr<BaseMenu> p) { v.push_back(p); }

	virtual void command()
	{
		while (1)
		{
			system("cls");

			int sz = v.size();

			for (int i = 0; i < sz; i++)
			{
				printf("%d. %s\n", i + 1, v[i]->getTitle().c_str());
			}

			printf("%d. �����޴��� �̵�\n", sz + 1);

			printf("�޴��� �����ϼ��� >>");
			int cmd;
			cin >> cmd;


			if (cmd < 1 || cmd > sz + 1)
				continue;

			if (cmd == sz + 1)
				break;

			v[cmd - 1]->command();

		}
	}
};

class MenuItem : public BaseMenu
{
	int id;
	using HANDLER = std::function<void()>;
	std::vector<HANDLER> v;
public:
	MenuItem(string s, int n, HANDLER h = nullptr) : BaseMenu(s), id(n)
	{
		if (h != nullptr)
			v.push_back(h);
	}
	void addHandler(HANDLER h) { v.push_back(h); }

	virtual void command()
	{
		for (auto f : v)
			f(); 
	}
};
//---------------------
void foo()      { std::cout << "foo" << std::endl; getchar(); }
void goo(int n) { std::cout << "goo" << std::endl; getchar(); }

int main()
{
	std::shared_ptr<PopupMenu> menubar = std::make_shared<PopupMenu>("MENUBAR");
	std::shared_ptr<PopupMenu> p1 = std::make_shared<PopupMenu>("���� ����");
	std::shared_ptr<PopupMenu> p2 = std::make_shared<PopupMenu>("�ػ� ����");

	menubar->addMenu(p1);
	menubar->addMenu(p2);

	p1->addMenu(std::make_shared<MenuItem>("RED", 11,   &foo) );
	p1->addMenu(std::make_shared<MenuItem>("GREEN", 12, std::bind(&goo, 12)));
	p2->addMenu(std::make_shared<MenuItem>("HD",  21,   std::bind(&goo, 21)));
	p2->addMenu(std::make_shared<MenuItem>("FHD", 22, []() {std::cout << "FHD" << std::endl; } ));

	menubar->command();
}

// C++ nana ��� "GUI ���̺귯��" �� �̺�Ʈ ó���� std::function ���� �մϴ�.
// ���ۿ��� "C++ nana" �˻�









