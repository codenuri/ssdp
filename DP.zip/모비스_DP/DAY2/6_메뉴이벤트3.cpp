// 2_�޴�2
#include <iostream>
#include <string>
#include <vector>
#include <conio.h> // _getch() �������..
using namespace std;

class BaseMenu
{
	string title;
public:
	BaseMenu(string s) : title(s) {}
	string getTitle() const { return title; }
	virtual void command() = 0;
};

class PopupMenu : public BaseMenu
{
	vector<BaseMenu*> v;
public:
	PopupMenu(string s) : BaseMenu(s) {}

	void addMenu(BaseMenu* p) { v.push_back(p); }

	virtual void command()
	{
		while (1)
		{
			system("cls");

			int sz = v.size();

			for (int i = 0; i < sz; i++)
			{
				printf("%d. %s\n", i + 1, v[i]->getTitle().c_str());
			}

			printf("%d. �����޴��� �̵�\n", sz + 1);

			printf("�޴��� �����ϼ��� >>");
			int cmd;
			cin >> cmd;


			if (cmd < 1 || cmd > sz + 1)
				continue;


			if (cmd == sz + 1)
				break;

			v[cmd - 1]->command();

		}
	}
};
//------------------
// ��� 3. �Լ������� ���
class MenuItem : public BaseMenu
{
	int id;

	void(*handler)() = nullptr;
public:
	MenuItem(string s, int n) : BaseMenu(s), id(n) {}

	void addHandler( void(*f)() ) { handler = f; }

	virtual void command()
	{
		if (handler != nullptr)
			handler();
	}
};

void foo() { std::cout << "foo" << std::endl; }

int main()
{
	MenuItem m1("���󺯰�", 11);
	m1.addHandler( &foo ); // event�� ó���� �Լ� ���
	m1.command();
}










