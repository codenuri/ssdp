#define USING_GUI
#include "cppmaster.h"
#include "ICalc.h"

int main()
{
	void* addr = ec_load_module("CalcProxy.dll");

	typedef ICalc*(*F)();

	F f = (F)ec_get_function_address(addr, "CreateProxy");

	//-------------------------
	ICalc* pCalc = f();
	pCalc->AddRef();

	cout << pCalc->Add(1, 2) << endl;
	cout << pCalc->Sub(1, 2) << endl;

	pCalc->Release();

	std::cout << "-----" << std::endl;
}







