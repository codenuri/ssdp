// IGraph.h
#pragma once

struct IGraph
{
	virtual void Update(int n) = 0;
	virtual ~IGraph() {}
};
