﻿// 1_생성자3.cpp
#include <string>
#include <iostream>

class Person
{
	std::string name;
	int age;
public:
	Person(const std::string& name, int age) : name(name), age(age) {}
};

// 1. 생성자를 추가해서 id 초기화 하세요
// 2. main 에서 Student 객체를 생성해 보세요
class Student : public Person
{
	int id;
public:

};

int main()
{

}


