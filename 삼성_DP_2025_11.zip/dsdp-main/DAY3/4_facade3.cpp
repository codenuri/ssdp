﻿#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <iostream>
#include <WinSock2.h>
#pragma comment(lib, "ws2_32.lib")
using namespace std;

// 단일 책임의 원칙
// => Single Responsibility Principle
// => 하나의 클래스에는 "하나의 책임만 부여" 해야 한다는 원칙

class NetworkInit
{
public:
	NetworkInit()
	{
		// 1. 네트워크 라이브러리 초기화
		WSADATA w;
		WSAStartup(0x202, &w);
	}
	~NetworkInit()
	{
		// 6. socket 라이브러리 cleanup
		WSACleanup();
	}
};
// IP 주소를 관리하는 클래스
class IPAddress
{
	SOCKADDR_IN addr;
public:
	IPAddress(const char* ip, short port)
	{
		addr.sin_family = AF_INET;
		addr.sin_port = htons(port);
		addr.sin_addr.s_addr = inet_addr(ip);
	}
	SOCKADDR* getRawAddress()
	{
		return (SOCKADDR*)&addr;
	}
};

// Socket 작업을 책임지는 클래스
class Socket
{
	int sock;
public:
	Socket(int type) { sock = socket(PF_INET, type, 0); }

	void Bind(IPAddress* ip)
	{
		::bind(sock, ip->getRawAddress(), sizeof(SOCKADDR_IN));
	}
	void Listen() { ::listen(sock, 5); }

	void Accept()
	{
		struct sockaddr_in addr2 = { 0 };
		int sz = sizeof(addr2);

		accept(sock, (SOCKADDR*)&addr2, &sz);
	}
};
// TCP 서버를 만들려면
// => 여러개 클래스를 사용해서 "여러 단계의 절차" 를 거쳐야 합니다.
// => 이런 과정 자체가 하나의 책임 입니다.
// => 이런 과정을 단순화 하는 클래스 제공

class TCPServer
{
	NetworkInit init;
	Socket sock{ SOCK_STREAM }; // 참고 멤버 데이타에서 생성자 인자 전달은 () 대신{} 사용
public:
	void Start(const char* ip, short port)
	{
		IPAddress addr(ip, port);
		sock.Bind(&addr);
		sock.Listen();
		sock.Accept();
	}
};
int main()
{
	TCPServer server;
	server.Start("127.0.0.1", 4000);

}



// 3차 API : TCP Server를 만들려면 2차 API 의 몇개의 클래스를 가지고
//           몇가지 절차를 거쳐야 한다.
//          => 이런 절차를 단순화하는 클래스 제공
//			=> "Facade(건물의 정면이라는 뜻)" 라고 부르는 패턴
//			=> "여러개클래스 + 여러 절차" => 하나의 인터페이스로 묶으라는것
// -------------------------------------------------------
// 2차 API : C++같은 객체지향 언어로 클래스로 제공
//		    => 아래 1차 API 의 각 요소와 1 : 1 로 매핑되는 
//             클래스 제공
// -------------------------------------------------------
// 1차 API : 다양한 분야(UI, DB, FILE, N/W등)에 대한 수천개 C함수
// -------------------------------------------------------
// OS      : windows, linux, ios, android .... <= 모두 C언어 로 제작