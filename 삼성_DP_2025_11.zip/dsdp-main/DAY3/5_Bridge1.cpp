﻿// 6_Bridge1 - 90 page
#include <iostream>

// 가전제품 도움말을 제작해서 배포 해야 한다면

// 도움말작성 ====> 고객1, 고객2, 고객3 에 우편 전달
// => 도움말이 UPDATE 되면 "모든 고객에게 다시 발송"

// 도움말작성 ==> 홈페이지에 게시 <== 고객1, 고객2, 고객3 확인
// => 도움말이 UPDATE 되면 홈페이지만 수정하면 됩니다.
// => 폰트등을 변경하려면 도움말 자체 변경은 필요 없고 홈페이지만 변경하면 됩니다.

// 즉, 계층을 늘리면 "UPDATE" 가 쉬워집니다.
// => bridge 개념

//----------------------------------------------------------
// 모든 MP3 제품의 공통의 인터페이스
struct IMP3
{
	virtual void play() = 0;
	virtual void stop() = 0;
	virtual ~IMP3() {}
};

class IPod : public IMP3
{
public:
	void play() { std::cout << "Play MP3 with IPod" << std::endl; }
	void stop() { std::cout << "Stop" << std::endl; }
};

class People
{
public:
//	void use(IPod* p)	// 강한 결합, 한가지 제품만 사용가능. 
	void use(IMP3* p)	// 약한 결합. 교체 가능. 다양한 제품 사용가능. 
	{					// => 하지만 아래와 같은 새로운 요구조건이 생기면 해결하기 어렵다
		p->play();
		p->stop();

		// 그런데, 사용자가 새로운 기능을 요구한다.
		p->play_one_minute(); // ??? 어떻게 해야 할까 ?
	}
};

int main()
{
	People p;
	IPod pod;
	p.Use(&pod);
}


