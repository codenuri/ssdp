﻿// 7_싱글톤1 - 123 page
#include <iostream>

// 싱글톤 : 오직 한개의 객체만 존재하고
//         어디에서건 동일한 방법으로 접근할수 있게 한다.

// 결국 "전역변수" 와 유사
// => 그런데, 전역변수는 "나쁜 코드"로 취급 됩니다.

// => 그래서, "싱글톤 패턴" 에 대한 비판도 아주 많습니다.
// => 그런데, 사용하는 경우도 꽤 많습니다.


class Cursor
{
	// 규칙 #1. private 생성자 
private:
	Cursor() {}

	// 규칙 #2. 컴파일러에게 복사 생성자, 대입연산자를 만들지 말라고 요청
	Cursor(const Cursor&) = delete;
	void operator=(const Cursor&) = delete; // 복사 금지시 대입도 금지하는게 관례


	// 규칙 #3. 오직 한개의 객체만 만들어서 반환하는 static 멤버 함수
public:
	static Cursor& get_instance()
	{
		static Cursor instance;
		return instance;
	}
};
int main()
{
	Cursor& c1 = Cursor::get_instance();
	Cursor& c2 = Cursor::get_instance();
	std::cout << &c1 << std::endl;
	std::cout << &c2 << std::endl;

//	Cursor c3 = c1; // 일반 생성자가 아닌 복사 생성자 사용!!!
					// => 복사생성자는 사용자가 만들지 않으면 컴파일러가 제공
					// => 이코드도 막아야 한다!!
					// => 컴파일러가 복사생성자를 만들지 못하도록 해야 한다.
}


// 위 코드가 "Effective-C++" 책의 저자인 "scott-mayer" 가 처음 제안한 코드
// => "mayer's singlton" 이라고 하고
// => C++로 만들수 있는 다양한 구현중 최선의 구현으로 알려진 코드






