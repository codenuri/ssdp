#define USING_GUI
#include "cppmaster.h"
#include "ICalc.h"

int main()
{
	sp<ICalc> calc1 = load_proxy();
	sp<ICalc> calc2 = calc1;

	std::cout << calc1->Add(1, 2) << std::endl;
}

