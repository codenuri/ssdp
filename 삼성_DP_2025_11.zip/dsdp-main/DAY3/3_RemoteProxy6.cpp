﻿#define USING_GUI
#include "cppmaster.h"

// 클라이언트 제작자는 "서버제작자에게 2개의 파일"을  받아야 합니다.
// ICalc.h       : 인터페이스가 있는 헤더
// CalcProxy.dll : Proxy 구현(기계어)이 담긴 동적 모듈

// 그리고 아래처럼만 만들면 됩니다
#include "ICalc.h"

int main()
{
	ICalc* calc = load_proxy();

	int n1 = calc->Add(10, 20);
	int n2 = calc->Sub(10, 20);

	std::cout << n1 << ", " << n2 << std::endl;
}

// 서버제작자는 새로운 Proxy 를 만들면
// => 반드시 "CalcProxy.dll" 의 이름을 사용해야 하고
// => Client 제작자에 배포해서 "DLL 을 덮어쓰게 합니다."

// => Client 를 만드는 사람은 "소스 변경", "다시 컴파일" 은 모두 필요없고
// => "다시 실행"만 하면 됩니다.
// => 또는 적절히 load_proxy()를 다시 호출할수 있는 방법을제공해도 됩니다.


// 정적라이브러리 : exe에 포함되는 라이브러리
// 동적라이브러리 : exe와 별도로 존재하고, 각각 메모리에 load 되는 라이브러리
