﻿#define USING_GUI
#include "cppmaster.h"

// 아래 코드는 C 스타일의 코드 입니다.
// 단점
// 1. 모든 클라이언트 개발자가 IPC 기술이 있어야 합니다.
// 
// 2. 서버 장애시 백업서버에 연결해야 한다면..
//    "모든 클라이언트에서 이 작업을 직접해야 합니다."

// 3. +하려면 1, - 하려면 2를 보내야 하는데, 이 코드를 외워야 합니다.
// => 명령 코드는 생각보다 많을수 있습니다.(수십~수백)
// => 가독성도 나쁩니다.



int main()
{
	// 1. 서버의 핸들을 얻어 옵니다.
	int server = ec_find_server("Calc");

	std::cout << "서버 번호 : " << server << std::endl;

	// 2. 서버에 명령코드와 파라미터를 전달합니다.
	int n1 = ec_send_server(server, 1, 10, 20);
	int n2 = ec_send_server(server, 2, 10, 20);

	std::cout << n1 << ", " << n2 << std::endl;

}





