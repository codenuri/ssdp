﻿#define USING_GUI
#include "cppmaster.h"

#include "ICalc.h"

int main()
{
	ICalc* calc = load_proxy();	// 1. DLL load
								// 2. DLL 내부의 create() 함수를 찾아서 호출
								// 3. DLL::create() 안에서 "new Calc"
								// => calc 사용후에는 "delete" 해야 하지 않을까요?


	delete calc; // 이렇게 해도 될까요 ?? 항상 안전할까요 ?

	// 문제점 : DLL 과 exe 는 다른 컴파일러 또는 다른 버전일수 있습니다.
	//		   new/delete 가 호환된다는  보장없습니다.

	// 해결책 : 동일모듈에서 new/delete 가 모두 있어야 합니다.


}

