﻿// github.com / codenuri / dsdp 에서 DAY3.zip

#include <iostream>
#include <string>
#include <vector>

// 아래 클래스가 이미 있었다고 가정해 봅시다.
// TextView : 문자열을 보관했다가 화면에 이쁘게 출력
// 
class TextView
{
	// 폰트, 크기, 색상, 두께.. 
	std::string data;
public:
	TextView(const std::string& s) : data(s) {}

	void show() { std::cout << data << std::endl; }
};




//---------------------------------
class Shape
{
public:
	virtual void draw() = 0;
	virtual ~Shape() {}
};

class Rect : public Shape
{
public:
	void draw() override { std::cout << "draw rect" << std::endl; }
};
class Circle : public Shape
{
public:
	void draw() override { std::cout << "draw circle" << std::endl; }
};
// 도형편집기 예제에서 "문자열" 을 다루는 클래스가 필요합니다.
// 예전 부터 가지고 있던, "TextView" 클래스를 여기서 사용할수 있을까요 ?

// Adapter 패턴
// => 인터페이스의 불일치를 해결하는 패턴
// => 기존 클래스의 인터페이스(함수이름)을 변경해서 클라이언트의 요구 조건으로 맞게 하는것


// TextView 클래스를 도형편집기에서 사용가능하게 해주는 "어답터"를 만들어 봅시다.

class Text : public Shape, public TextView
{
public:
	Text(const std::string& s) : TextView(s) {}

	// 아래 코드가 이 예제의 핵심
	// "show" 라는 멤버함수 이름을 "draw" 라는 이름으로 사용가능하도록
	// 변경한것
	void draw() override
	{
		TextView::show();
	}
};
int main()
{
	std::vector<Shape*> v;

//	v.push_back(new TextView("hello")); // error
	v.push_back(new Text("hello"));     // ok

	v[0]->draw();
}







