﻿#include <iostream>

// 오직 한개를 객체를 "힙(new)" 에 만드는 모델

class Cursor
{
private:
	Cursor() {}
	Cursor(const Cursor&) = delete;
	void operator=(const Cursor&) = delete; 

	static Cursor* instance;
public:
	static Cursor& get_instance()
	{
		if (instance == nullptr)
		{
			instance = new Cursor;
		}		
		return *instance;
	}
};
Cursor* Cursor::instance = nullptr;





int main()
{
	Cursor& c1 = Cursor::get_instance();

}



