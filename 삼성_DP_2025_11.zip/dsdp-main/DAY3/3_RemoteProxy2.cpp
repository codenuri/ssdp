﻿#define USING_GUI
#include "cppmaster.h"

// 서버를 대신하는 Proxy 를 만들어 봅시다.

// Calc 는 결국 "서버를 대신" 하게 됩니다.

// #1. 클라이언트 개발자가 "IPC 기술"을 몰라도 됩니다.

// #2. 서버 장애시 백업서버 연결등의 기능을 추가하려면 Proxy 에만 만들면됩니다.
//	   => 자주 사용하는 연산에 대한 캐쉬도 제공 가능합니다.
//     => 내부적으로 주기적으로 서버와 통신하면서 서버가 살아 있는지도 확인가능
// 
// #3. 1, 2 등의 명령 코드가 아닌 "Add", "Sub" 사용
// => 가독성 증가

class Calc
{
	int server;
public:
	Calc() { server = ec_find_server("Calc"); }

	int Add(int a, int b) { return ec_send_server(server, 1, a, b);} 
	int Sub(int a, int b) { return ec_send_server(server, 2, a, b); }
};

int main()
{
	Calc* calc = new Calc;

	int n1 = calc->Add(10, 20);
	int n2 = calc->Sub(10, 20);

	std::cout << n1 << ", " << n2 << std::endl;

}





