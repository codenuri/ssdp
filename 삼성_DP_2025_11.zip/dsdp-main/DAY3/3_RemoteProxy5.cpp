﻿#define USING_GUI
#include "cppmaster.h"

// 클라이언트 제작자는 "서버제작자에게 2개의 파일"을  받아야 합니다.
// ICalc.h       : 인터페이스가 있는 헤더
// CalcProxy.dll : Proxy 구현(기계어)이 담긴 동적 모듈
#include "ICalc.h"

ICalc* load_proxy()
{
	// #1. DLL load
	void* addr = ec_load_module("CalcProxy.dll");
				// Windows : LoadLibrary(),  Linux : dlopen()

	// #2. dll 에서 약속된 함수를 찾아야 합니다.
	typedef ICalc(*F)();  // F 는 함수의 주소를 담는 타입

	F f = (F)ec_get_function_address(addr, "create");
				// windows : GetProcAddress(), Linux : dlsym()

	// #3. 약속된 함수를 호출해서 Proxy 객체 생성후 주소 반환
	ICalc* calc = f();

	return calc; 
}


int main()
{
	ICalc* calc = load_proxy();  

	int n1 = calc->Add(10, 20);
	int n2 = calc->Sub(10, 20);

	std::cout << n1 << ", " << n2 << std::endl;

}





