﻿// 디자인 패턴을 열심히 공부하면...
// 어느 순간 서로 다른 패턴이 동일하게 보이게 됩니다.
// => 이때는 "의도"를 생각하세요..

// Decorator vs Adaptor
class ZipDecorator : public Stream
{
	Stream* origin;
public:
	ZipDecorator(Stream* s) : origin(s) {}

	void write(const std::string& s) override
	{
		auto s2 = "[ " + s + "] 압축됨";

		origin->write(s2);
	}
};

FileStream fs("a.txt");
ZipDecorator zd(&fs);

// 데코레이터 : 사용법(인터페이스)는 동일하지만, 기능을 추가한것
fs.write("hello");
zd.write("hello");


class ObjectAdapter : public Shape
{
	TextView* origin; 
public:
	ObjectAdapter(TextView* tv) : origin(tv) {}

	void draw() override { origin->show(); }
};

TextView tv("hello");
ObjectAdapter oa(&tv);

// 어답터 : 기능을 동일하지만, 인터페이스를 변경하기 위한 것
tv.show();
oa.draw();