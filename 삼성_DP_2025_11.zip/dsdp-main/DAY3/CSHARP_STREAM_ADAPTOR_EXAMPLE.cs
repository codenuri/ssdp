﻿using System.IO;
using System.IO.Compression;

// 파일 스트림 생성
FileStream fs = new FileStream("a.dat", FileMode.Create);

// #1. C# stream 은 byte[] 로만 쓰기 가능.
byte[] data = new byte[1024];
fs.Write(data, 0, data.Length);

// #2. decorator 를 사용해도 쓰기는 byte[]
GZipStream zs = new GZipStream(fs, CompressionMode.Compress);
zs.Write(data, 0, data.Length); 

// #3. Adapter 를 적용하면 다양한 포맷으로 쓰기 가능
StreamWriter sw = new StreamWriter(fs);
sw.WriteLine("n = {}, d = {}", 10, 3.4);

