﻿#include <iostream>
#include <list>
#include <vector>
#include <deque>

// STL 과 Adapter


int main()
{
	stack<int> s;
	s.push(10);
}
